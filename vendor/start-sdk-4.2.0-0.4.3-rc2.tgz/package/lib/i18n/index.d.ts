/**
 * Internationalization (i18n) utilities for StartOS packages.
 *
 * @example
 * ```typescript
 * // In package's i18n/index.ts:
 * import { setupI18n } from '@start9labs/start-sdk'
 * import defaultDict, { DEFAULT_LANG } from './dictionaries/default'
 * import translations from './dictionaries/translations'
 *
 * export const i18n = setupI18n(defaultDict, translations, DEFAULT_LANG)
 * ```
 */
type ParamValue = string | number | Date;
/**
 * Creates a typed i18n function for a package.
 *
 * @param defaultDict - The default language dictionary mapping strings to numeric indices
 * @param translations - Translation dictionaries for each supported locale
 * @param defaultLang - The default language code (e.g., 'en_US')
 * @returns A typed i18n function that accepts dictionary keys and optional parameters
 */
export declare function setupI18n<Dict extends Record<string, number>, Translations extends Record<string, Record<number, string>>>(defaultDict: Dict, translations: Translations, defaultLang: string): (key: keyof Dict, params?: Record<string, ParamValue>) => string;
export {};
