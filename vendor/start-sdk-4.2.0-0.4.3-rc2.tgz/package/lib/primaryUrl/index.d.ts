export * from './setupPrimaryUrl';
