import { Action, MaybeFn } from '@start9labs/start-core/actions/setupActions';
import { InitScript } from '@start9labs/start-core/inits';
import * as T from '@start9labs/start-core/types';
import { Watchable } from '@start9labs/start-core/util/Watchable';
import { Filter } from '@start9labs/start-core/util/filledAddress';
/** A reader in the shape `FileHelper.read()` returns. */
export type Reader<A> = {
    once(): Promise<A>;
    watch(effects: T.Effects, abort?: AbortSignal): AsyncGenerator<A, unknown>;
};
export type SetupPrimaryUrlParams<Id extends T.ActionId> = {
    /** The id of the action that sets the URL. */
    id: Id;
    /** The id given to `sdk.MultiHost.of` for the host the interface is exported from. */
    hostId: T.HostId;
    /** The exported interface whose addresses the user chooses from. */
    interfaceId: T.ServiceInterfaceId;
    /** The action's metadata, as for `sdk.Action.withInput`. */
    metadata: MaybeFn<Omit<T.ActionMetadataInput, 'hasInput'>>;
    /** The label and description of the URL select. */
    field: {
        name: string;
        description: string | null;
    };
    /** Reads the stored URL, e.g. `storeJson.read(s => s.primaryUrl)`. */
    get: Reader<string | null | undefined>;
    /** Stores the URL the user chose. */
    set: (effects: T.Effects, url: string) => Promise<unknown>;
    /** Narrows the addresses offered, on top of dropping loopback, link-local and bridge ones. */
    filter?: Filter;
    /** Offer only addresses served over TLS. */
    ssl?: boolean;
    /**
     * `false` when the service must run only on an address the user chose: the
     * form and task start empty, and `bestUsable` is `null` while nothing is
     * stored or the stored URL is gone. Defaults to `true`.
     */
    fallback?: boolean;
};
export type PrimaryUrl<Id extends T.ActionId> = {
    /** The action that sets the URL. Register it with `sdk.Actions.of()`. */
    action: Action<Id, {
        url: string;
    }>;
    /**
     * Reader for the URL the service should use: the stored one, followed to its
     * hostname's current port and scheme; else the preferred address (see
     * `setupTask`), unless `fallback` is `false`.
     */
    bestUsable: (effects: T.Effects) => Watchable<string | null>;
    /**
     * Raises a task on `action` while the stored URL is unset or no longer one
     * of the interface's addresses, and clears it otherwise. Unless `fallback`
     * is `false`, the task pre-fills the preferred address: a public domain,
     * HTTPS first; else the `.local` address; else the first. Register it
     * with `sdk.setupInit()`, after the actions.
     */
    setupTask: (severity: T.TaskSeverity, options?: {
        reason?: string;
        replayId?: string;
    }) => InitScript;
};
export declare function setupPrimaryUrl<Id extends T.ActionId>(packageId: T.PackageId, { id, hostId, interfaceId, metadata, field, get, set, filter, ssl, fallback, }: SetupPrimaryUrlParams<Id>): PrimaryUrl<Id>;
