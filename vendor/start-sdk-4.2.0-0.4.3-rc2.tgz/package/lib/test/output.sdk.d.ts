export type Manifest = any;
export declare const sdk: {
    prepareUpload: (effects: import("@start9labs/start-core/Effects.js").Effects, options: Omit<{
        volume: string;
        path: string;
        mode?: number | null | undefined;
        uid?: number | null | undefined;
        gid?: number | null | undefined;
    } & {
        maxSize?: number | null | undefined;
    }, "volume"> & {
        volume: never;
    }) => Promise<string>;
    prepareDownload: (effects: import("@start9labs/start-core/Effects.js").Effects, options: Omit<{
        volume: string;
        path: string;
        mime?: string | null | undefined;
        filename?: string | null | undefined;
    }, "volume"> & {
        volume: never;
    }) => Promise<string>;
    setDataVersion: typeof import("..").setDataVersion;
    getDataVersion: typeof import("..").getDataVersion;
    action: {
        run: <Input extends Record<string, unknown>>(options: {
            effects: import("@start9labs/start-core/Effects.js").Effects;
            packageId?: import("@start9labs/start-core/types.js").PackageId;
            actionId: import("@start9labs/start-core/osBindings").ActionId;
            prefill?: import("@start9labs/start-core/types.js").DeepPartial<Input> | null;
            input?: import("@start9labs/start-core/actions").RunActionInput<Input>;
        }) => Promise<({
            version: "0";
        } & {
            message: string;
            value: string | null;
            copyable: boolean;
            qr: boolean;
        }) | ({
            version: "1";
        } & {
            title: string;
            message: string | null;
            result: ({
                type: "file";
            } & {
                value: string;
                delete: boolean;
            }) | ({
                type: "single";
            } & {
                value: string;
                copyable: boolean | null;
                qr: boolean | null;
                masked: boolean | null;
                launchable: boolean | null;
            }) | ({
                type: "multiline";
            } & {
                value: string;
                copyable: boolean | null;
                qr: boolean | null;
                masked: boolean | null;
                filename: string | null;
            }) | ({
                type: "group";
            } & {
                value: ({
                    name: string;
                    description: string | null;
                } & (({
                    type: "file";
                } & {
                    value: string;
                    delete: boolean;
                }) | ({
                    type: "single";
                } & {
                    value: string;
                    copyable: boolean | null;
                    qr: boolean | null;
                    masked: boolean | null;
                    launchable: boolean | null;
                }) | ({
                    type: "multiline";
                } & {
                    value: string;
                    copyable: boolean | null;
                    qr: boolean | null;
                    masked: boolean | null;
                    filename: string | null;
                }) | ({
                    type: "group";
                } & any)))[];
            }) | null;
        }) | null>;
        createTask: <T extends import("@start9labs/start-core/actions/setupActions.js").ActionInfo<import("@start9labs/start-core/osBindings").ActionId, any>>(effects: import("@start9labs/start-core/Effects.js").Effects, packageId: import("@start9labs/start-core/types.js").PackageId, action: T, severity: import("@start9labs/start-core/osBindings").TaskSeverity, options?: import("@start9labs/start-core/actions").TaskOptions<T> | undefined) => Promise<null>;
        createOwnTask: <T extends import("@start9labs/start-core/actions/setupActions.js").ActionInfo<import("@start9labs/start-core/osBindings").ActionId, any>>(effects: import("@start9labs/start-core/Effects.js").Effects, action: T, severity: import("@start9labs/start-core/osBindings").TaskSeverity, options?: import("@start9labs/start-core/actions").TaskOptions<T> | undefined) => Promise<null>;
        clearTask: (effects: import("@start9labs/start-core/Effects.js").Effects, ...replayIds: string[]) => Promise<null>;
    };
    notification: {
        create: (effects: import("@start9labs/start-core/Effects.js").Effects, options: import("@start9labs/start-core/osBindings").CreateNotificationParamsInput) => Promise<null>;
    };
    host: {
        getOwn: typeof import("@start9labs/start-core/util/GetHostInfo.js").getOwnHost;
        get: typeof import("@start9labs/start-core/util/GetHostInfo.js").getHost;
        getAddressGateways: typeof import("../util/getAddressGateways").getAddressGateways;
        getBridgeAddress: typeof import("@start9labs/start-core/util/GetHostInfo.js").getBridgeAddress;
    };
    getContainerIp: <Opts extends {
        packageId?: import("@start9labs/start-core/types.js").PackageId;
    } = {}>(effects: import("@start9labs/start-core/Effects.js").Effects, options?: Opts) => import("@start9labs/start-core/util").GetContainerIp<Opts>;
    getStatus: (effects: import("@start9labs/start-core/Effects.js").Effects, options?: Omit<Parameters<import("@start9labs/start-core/Effects.js").Effects["getStatus"]>[0], "callback">) => import("@start9labs/start-core/util").GetStatus;
    MultiHost: {
        of: (effects: import("@start9labs/start-core/Effects.js").Effects, id: string) => import("@start9labs/start-core/interfaces/Host.js").MultiHost;
    };
    nullIfEmpty: typeof import("@start9labs/start-core/util").nullIfEmpty;
    useEntrypoint: (overrideCmd?: string[]) => import("@start9labs/start-core/types.js").UseEntrypoint;
    Action: {
        withInput: <Id extends import("@start9labs/start-core/osBindings").ActionId, InputSpecType extends import("@start9labs/start-core/actions/input/builder").InputSpec<Record<string, any>>>(id: Id, metadata: import("@start9labs/start-core/actions/setupActions.js").MaybeFn<Omit<import("@start9labs/start-core/osBindings").ActionMetadataInput, "hasInput">>, inputSpec: import("@start9labs/start-core/actions/setupActions.js").MaybeFn<InputSpecType, {
            effects: import("@start9labs/start-core/Effects.js").Effects;
            prefill: unknown | null;
            caller: import("@start9labs/start-core/actions/setupActions.js").ActionCaller;
        }>, getInput: import("@start9labs/start-core/actions/setupActions.js").GetInput<import("@start9labs/start-core/actions/input/builder/inputSpec.js").ExtractInputSpecType<InputSpecType>>, run: import("@start9labs/start-core/actions/setupActions.js").Run<import("@start9labs/start-core/actions/input/builder/inputSpec.js").ExtractInputSpecType<InputSpecType>>) => import("@start9labs/start-core/actions/setupActions.js").Action<Id, import("@start9labs/start-core/actions/input/builder/inputSpec.js").ExtractInputSpecType<InputSpecType>>;
        withoutInput: <Id extends import("@start9labs/start-core/osBindings").ActionId>(id: Id, metadata: import("@start9labs/start-core/actions/setupActions.js").MaybeFn<Omit<import("@start9labs/start-core/osBindings").ActionMetadataInput, "hasInput">>, run: import("@start9labs/start-core/actions/setupActions.js").Run<{}>) => import("@start9labs/start-core/actions/setupActions.js").Action<Id, {}>;
    };
    inputSpecConstants: {
        smtpInputSpec: import("@start9labs/start-core/actions/input/builder").Value<import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
            disabled: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{}, {}>;
            };
            system: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    customFrom: string | null;
                }, {
                    customFrom: string | null;
                }>;
            };
            custom: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    provider: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                        ses: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        forwardemail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        gmail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        mailgun: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        protonmail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        sendgrid: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        other: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                    }, "other" | "ses" | "forwardemail" | "gmail" | "mailgun" | "protonmail" | "sendgrid">;
                }, {
                    provider: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                        ses: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        forwardemail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        gmail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        mailgun: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        protonmail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        sendgrid: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        other: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                    }, "other" | "ses" | "forwardemail" | "gmail" | "mailgun" | "protonmail" | "sendgrid">;
                }>;
            };
        }, "custom" | "disabled" | "system">, import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
            disabled: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{}, {}>;
            };
            system: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    customFrom: string | null;
                }, {
                    customFrom: string | null;
                }>;
            };
            custom: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    provider: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                        ses: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        forwardemail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        gmail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        mailgun: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        protonmail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        sendgrid: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        other: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                    }, "other" | "ses" | "forwardemail" | "gmail" | "mailgun" | "protonmail" | "sendgrid">;
                }, {
                    provider: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                        ses: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        forwardemail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        gmail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        mailgun: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        protonmail: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        sendgrid: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                        other: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }, {
                                host: string;
                                security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                                    tls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: string;
                                        }, {
                                            port: string | null;
                                        }>;
                                    };
                                    starttls: {
                                        name: string;
                                        spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                            port: "587" | "25" | "2525";
                                        }, {
                                            port: "587" | "25" | "2525";
                                        }>;
                                    };
                                }, "starttls" | "tls">;
                                from: string;
                                username: string;
                                password: string | null;
                            }>;
                        };
                    }, "other" | "ses" | "forwardemail" | "gmail" | "mailgun" | "protonmail" | "sendgrid">;
                }>;
            };
        }, "custom" | "disabled" | "system">, unknown>;
        systemSmtpSpec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
            provider: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                ses: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                forwardemail: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                gmail: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                mailgun: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                protonmail: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                sendgrid: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                other: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
            }, "other" | "ses" | "forwardemail" | "gmail" | "mailgun" | "protonmail" | "sendgrid">;
        }, {
            provider: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                ses: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                forwardemail: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                gmail: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                mailgun: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                protonmail: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                sendgrid: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
                other: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }, {
                        host: string;
                        security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                            tls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: string;
                                }, {
                                    port: string | null;
                                }>;
                            };
                            starttls: {
                                name: string;
                                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                    port: "587" | "25" | "2525";
                                }, {
                                    port: "587" | "25" | "2525";
                                }>;
                            };
                        }, "starttls" | "tls">;
                        from: string;
                        username: string;
                        password: string | null;
                    }>;
                };
            }, "other" | "ses" | "forwardemail" | "gmail" | "mailgun" | "protonmail" | "sendgrid">;
        }>;
        customSmtp: import("@start9labs/start-core/actions/input/builder").InputSpec<{
            host: string;
            security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                tls: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        port: string;
                    }, {
                        port: string | null;
                    }>;
                };
                starttls: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        port: "587" | "25" | "2525";
                    }, {
                        port: "587" | "25" | "2525";
                    }>;
                };
            }, "starttls" | "tls">;
            from: string;
            username: string;
            password: string | null;
        }, {
            host: string;
            security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                tls: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        port: string;
                    }, {
                        port: string | null;
                    }>;
                };
                starttls: {
                    name: string;
                    spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                        port: "587" | "25" | "2525";
                    }, {
                        port: "587" | "25" | "2525";
                    }>;
                };
            }, "starttls" | "tls">;
            from: string;
            username: string;
            password: string | null;
        }>;
        smtpProviderVariants: import("@start9labs/start-core/actions/input/builder").Variants<{
            ses: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }, {
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }>;
            };
            forwardemail: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }, {
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }>;
            };
            gmail: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }, {
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }>;
            };
            mailgun: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }, {
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }>;
            };
            protonmail: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }, {
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }>;
            };
            sendgrid: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }, {
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }>;
            };
            other: {
                name: string;
                spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionRes<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }, {
                    host: string;
                    security: import("@start9labs/start-core/actions/input/builder/variants.js").UnionResStaticValidatedAs<{
                        tls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: string;
                            }, {
                                port: string | null;
                            }>;
                        };
                        starttls: {
                            name: string;
                            spec: import("@start9labs/start-core/actions/input/builder").InputSpec<{
                                port: "587" | "25" | "2525";
                            }, {
                                port: "587" | "25" | "2525";
                            }>;
                        };
                    }, "starttls" | "tls">;
                    from: string;
                    username: string;
                    password: string | null;
                }>;
            };
        }, unknown>;
    };
    createInterface: (effects: import("@start9labs/start-core/Effects.js").Effects, options: {
        name: string;
        id: string;
        description: string;
        type: import("@start9labs/start-core/types.js").ServiceInterfaceType;
        username: null | string;
        path: string;
        query: Record<string, string>;
        schemeOverride: {
            ssl: import("@start9labs/start-core/interfaces/Host.js").Scheme;
            noSsl: import("@start9labs/start-core/interfaces/Host.js").Scheme;
        } | null;
        masked: boolean;
        preferredLauncherAddress?: string | null;
    }) => import("@start9labs/start-core/interfaces/ServiceInterfaceBuilder.js").ServiceInterfaceBuilder;
    createRangeInterface: (effects: import("@start9labs/start-core/Effects.js").Effects, options: {
        id: string;
        name: string;
        description: string;
        scheme?: string | null;
    }) => import("@start9labs/start-core/interfaces/RangeInterfaceBuilder.js").RangeInterfaceBuilder;
    getSystemSmtp: <E extends import("@start9labs/start-core/Effects.js").Effects>(effects: E) => import("@start9labs/start-core/util").GetSystemSmtp;
    getOutboundGateway: <E extends import("@start9labs/start-core/Effects.js").Effects>(effects: E) => import("@start9labs/start-core/util").GetOutboundGateway;
    getSslCertificate: <E extends import("@start9labs/start-core/Effects.js").Effects>(effects: E, hostnames: string[], algorithm?: import("@start9labs/start-core/osBindings").Algorithm) => import("@start9labs/start-core/util").GetSslCertificate;
    getRootCa: typeof import("@start9labs/start-core/util").getRootCa;
    getServiceManifest: typeof import("@start9labs/start-core/util").getServiceManifest;
    getSharedVolumes: (effects: never) => import("@start9labs/start-core/util").GetSharedVolumes;
    healthCheck: {
        checkPortListening: typeof import("../health/checkFns").checkPortListening;
        checkWebUrl: (effects: import("@start9labs/start-core/Effects.js").Effects, url: string, { timeout, successMessage, errorMessage, }?: {
            timeout?: number | undefined;
            successMessage?: string | undefined;
            errorMessage?: string | undefined;
        }) => Promise<import("../health/checkFns").HealthCheckResult>;
        runHealthScript: <Manifest extends import("@start9labs/start-core/types.js").SDKManifest>(runCommand: string[], subcontainer: import("..").SubContainer<Manifest>, { timeout, errorMessage, message, }?: {
            timeout?: number | undefined;
            errorMessage?: string | undefined;
            message?: ((res: string) => string) | undefined;
        }) => Promise<import("../health/checkFns").HealthCheckResult>;
    };
    patterns: typeof import("@start9labs/start-core/util/patterns.js");
    Actions: {
        of(): import("@start9labs/start-core/actions/setupActions.js").Actions<{}>;
    };
    setupBackups: (options: import("../backup").SetupBackupsParams<{
        readonly id: "testOutput";
        readonly title: "";
        readonly license: "";
        readonly packageRepo: "";
        readonly upstreamRepo: "";
        readonly marketingUrl: "";
        readonly donationUrl: null;
        readonly description: {
            readonly short: "";
            readonly long: "";
        };
        readonly images: {
            readonly main: {
                readonly source: {
                    readonly dockerTag: "start9/hello-world";
                };
                readonly arch: ["aarch64", "x86_64"];
                readonly emulateMissing: true;
            };
        };
        readonly volumes: [];
    }>) => {
        createBackup: import("@start9labs/start-core/types.js").ExpectedExports.createBackup;
        restoreInit: import("@start9labs/start-core/inits").InitScript;
    };
    setupPrimaryUrl: <Id extends import("@start9labs/start-core/osBindings").ActionId>(params: import("../primaryUrl").SetupPrimaryUrlParams<Id>) => import("../primaryUrl").PrimaryUrl<Id>;
    setupOnInit: typeof import("@start9labs/start-core/inits").setupOnInit;
    setupOnUninit: typeof import("@start9labs/start-core/inits").setupOnUninit;
    setupInit: typeof import("@start9labs/start-core/inits").setupInit;
    setupUninit: typeof import("@start9labs/start-core/inits").setupUninit;
    setupInterfaces: import("@start9labs/start-core/interfaces/setupInterfaces.js").SetupServiceInterfaces;
    setupMain: (fn: (o: {
        effects: import("@start9labs/start-core/Effects.js").Effects;
    }) => Promise<import("@start9labs/start-core/types.js").DaemonBuildable>) => import("@start9labs/start-core/types.js").ExpectedExports.main;
    trigger: {
        defaultTrigger: import("../trigger").Trigger;
        cooldownTrigger: typeof import("../trigger").cooldownTrigger;
        onceTrigger: import("../trigger").Trigger;
        statusTrigger: typeof import("../trigger").statusTrigger;
    };
    Mounts: {
        of: () => import("../mainFn/Mounts").Mounts<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>;
    };
    Backups: {
        ofVolumes: (...volumeNames: never[]) => import("../backup").Backups<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>;
        ofSyncs: (...syncs: import("../backup").BackupSync<never>[]) => import("../backup").Backups<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>;
        withOptions: (options?: Partial<import("@start9labs/start-core/types.js").SyncOptions>) => import("../backup").Backups<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>;
        withPgDump: (config: import("../backup").PgDumpConfig<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>) => import("../backup").Backups<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>;
        withMysqlDump: (config: import("../backup").MysqlDumpConfig<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>) => import("../backup").Backups<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>;
        withMariadbDump: (config: import("../backup").MariadbDumpConfig<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>) => import("../backup").Backups<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>;
    };
    InputSpec: {
        of: <Spec extends Record<string, import("@start9labs/start-core/actions/input/builder").Value<any>>>(spec: Spec) => import("@start9labs/start-core/actions/input/builder").InputSpec<{ [K in keyof Spec]: Spec[K] extends import("@start9labs/start-core/actions/input/builder").Value<infer T extends unknown, any, unknown> ? T : never; }, { [K_1 in keyof Spec]: Spec[K_1] extends import("@start9labs/start-core/actions/input/builder").Value<any, infer T, unknown> ? T : never; }>;
    };
    Daemon: {
        readonly of: <C extends import("..").SubContainer<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }, import("@start9labs/start-core/Effects.js").Effects> | null>(effects: import("@start9labs/start-core/Effects.js").Effects, subcontainer: C, exec: import("../mainFn/Daemons").DaemonCommandType<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }, C>) => import("../mainFn/Daemon").Daemon<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }, C>;
    };
    Daemons: {
        of(effects: import("@start9labs/start-core/Effects.js").Effects): import("..").Daemons<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }, never>;
        dynamic(effects: import("@start9labs/start-core/Effects.js").Effects, fn: (o: {
            effects: import("@start9labs/start-core/Effects.js").Effects;
        }) => import("..").Daemons<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }, any> | Promise<import("..").Daemons<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }, any>>): import("..").DaemonsReconciler<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }>;
    };
    SubContainer: {
        of(effects: import("@start9labs/start-core/Effects.js").Effects, image: {
            imageId: "main";
            sharedRun?: boolean;
        }, mounts: import("../mainFn/Mounts").Mounts<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }> | null, name: string): import("..").SubContainerLazy<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }, import("@start9labs/start-core/Effects.js").Effects>;
        eager(effects: import("@start9labs/start-core/Effects.js").Effects, image: {
            imageId: "main";
            sharedRun?: boolean;
        }, mounts: import("../mainFn/Mounts").Mounts<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }> | null, name: string): Promise<import("..").SubContainerEager<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }, import("@start9labs/start-core/Effects.js").Effects>>;
        withTemp<T>(effects: import("@start9labs/start-core/Effects.js").Effects, image: {
            imageId: "main";
            sharedRun?: boolean;
        }, mounts: import("../mainFn/Mounts").Mounts<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }> | null, name: string, fn: (subContainer: import("..").SubContainerEager<{
            readonly id: "testOutput";
            readonly title: "";
            readonly license: "";
            readonly packageRepo: "";
            readonly upstreamRepo: "";
            readonly marketingUrl: "";
            readonly donationUrl: null;
            readonly description: {
                readonly short: "";
                readonly long: "";
            };
            readonly images: {
                readonly main: {
                    readonly source: {
                        readonly dockerTag: "start9/hello-world";
                    };
                    readonly arch: ["aarch64", "x86_64"];
                    readonly emulateMissing: true;
                };
            };
            readonly volumes: [];
        }, import("@start9labs/start-core/Effects.js").Effects>) => Promise<T>): Promise<T>;
    };
    List: typeof import("@start9labs/start-core/actions/input/builder").List;
    Value: typeof import("@start9labs/start-core/actions/input/builder").Value;
    Variants: typeof import("@start9labs/start-core/actions/input/builder").Variants;
    plugin: {
        url: null;
    };
    mountSharedVolume: (effects: import("@start9labs/start-core/Effects.js").Effects, options: {
        id: string;
        subcontainer: string;
        mountpoint: string;
        readonly: boolean;
        subpath?: string | null | undefined;
    }) => Promise<{
        kind: "mounted";
    } | ({
        kind: "unavailable";
    } & {
        reason: "sourceUnavailable" | "timeout";
    })>;
    mount: (effects: import("@start9labs/start-core/Effects.js").Effects, options: {
        location: string;
        target: {
            packageId: string;
            volumeId: string;
            readonly: boolean;
            subpath?: string | null | undefined;
            idmap?: {
                fromId: number;
                toId: number;
                range: number;
            }[] | undefined;
        };
    }) => Promise<null>;
    restart: (effects: import("@start9labs/start-core/Effects.js").Effects) => Promise<null>;
    shutdown: (effects: import("@start9labs/start-core/Effects.js").Effects) => Promise<null>;
    setDependencies: (effects: import("@start9labs/start-core/Effects.js").Effects, options: {
        dependencies: import("@start9labs/start-core/types.js").Dependencies;
    }) => Promise<null>;
    getDependencies: (effects: import("@start9labs/start-core/Effects.js").Effects) => Promise<(({
        kind: "running";
    } & {
        id: string;
        healthChecks: string[];
        versionRange: string;
    }) | ({
        kind: "exists";
    } & {
        id: string;
        versionRange: string;
    }))[]>;
    checkDependencies: (effects: import("@start9labs/start-core/Effects.js").Effects, options: {
        packageIds?: import("@start9labs/start-core/types.js").PackageId[];
    }) => Promise<{
        packageId: string;
        title: string | null;
        installedVersion: string | null;
        satisfies: string[];
        isRunning: boolean;
        tasks: Record<string, {
            task: {
                packageId: string;
                actionId: string;
                severity: "optional" | "important" | "critical";
                reason: string | null;
                when: {
                    once: boolean;
                    condition: "input-not-matches";
                } | null;
                input: ({
                    kind: "partial";
                } & {
                    accept: Record<string, unknown>[];
                    set: Record<string, unknown>;
                }) | null;
            };
            active: boolean;
        }>;
        healthChecks: Record<string, {
            name: string;
        } & (({
            result: "success";
        } & {
            message: string | null;
        }) | ({
            result: "disabled";
        } & {
            message: string | null;
        }) | ({
            result: "starting";
        } & {
            message: string | null;
            waiting: boolean;
        }) | ({
            result: "loading";
        } & {
            message: string;
            waiting: boolean;
        }) | ({
            result: "failure";
        } & {
            message: string;
        }))>;
    }[]>;
    getInstalledPackages: (effects: import("@start9labs/start-core/Effects.js").Effects) => Promise<string[]>;
    setBackupProgress: (effects: import("@start9labs/start-core/Effects.js").Effects, o: {
        progress: import("@start9labs/start-core/osBindings").Progress;
    }) => Promise<null>;
    setInitProgress: (effects: import("@start9labs/start-core/Effects.js").Effects, o: {
        progress: import("@start9labs/start-core/osBindings").Progress;
    }) => Promise<null>;
    setHealth: (effects: import("@start9labs/start-core/Effects.js").Effects, o: {
        id: string;
    } & ({
        name: string;
    } & (({
        result: "success";
    } & {
        message?: string | null | undefined;
    }) | ({
        result: "disabled";
    } & {
        message?: string | null | undefined;
    }) | ({
        result: "starting";
    } & {
        message?: string | null | undefined;
        waiting?: boolean | undefined;
    }) | ({
        result: "loading";
    } & {
        message: string;
        waiting?: boolean | undefined;
    }) | ({
        result: "failure";
    } & {
        message: string;
    }) | ({
        result: "waiting";
    } & {
        message?: string | null | undefined;
    })))) => Promise<null>;
    getServicePortForward: (effects: import("@start9labs/start-core/Effects.js").Effects, options: {
        packageId?: import("@start9labs/start-core/types.js").PackageId;
        hostId: import("@start9labs/start-core/osBindings").HostId;
        internalPort: number;
    }) => Promise<{
        assignedPort: number | null;
        assignedSslPort: number | null;
    } | null>;
    clearBindings: (effects: import("@start9labs/start-core/Effects.js").Effects, options: {
        except: {
            id: import("@start9labs/start-core/osBindings").HostId;
            internalPort: number;
        }[];
    }) => Promise<null>;
    getOsIp: (effects: import("@start9labs/start-core/Effects.js").Effects) => Promise<string>;
    getSslKey: (effects: import("@start9labs/start-core/Effects.js").Effects, options: {
        hostnames: string[];
        algorithm?: "ecdsa" | "ed25519";
    }) => Promise<string>;
    manifest: {
        readonly id: "testOutput";
        readonly title: "";
        readonly license: "";
        readonly packageRepo: "";
        readonly upstreamRepo: "";
        readonly marketingUrl: "";
        readonly donationUrl: null;
        readonly description: {
            readonly short: "";
            readonly long: "";
        };
        readonly images: {
            readonly main: {
                readonly source: {
                    readonly dockerTag: "start9/hello-world";
                };
                readonly arch: ["aarch64", "x86_64"];
                readonly emulateMissing: true;
            };
        };
        readonly volumes: [];
    };
    Dependency: typeof import("..").Dependency;
    Dependencies: typeof import("..").Dependencies;
    volumes: import("../util").Volumes<{
        readonly id: "testOutput";
        readonly title: "";
        readonly license: "";
        readonly packageRepo: "";
        readonly upstreamRepo: "";
        readonly marketingUrl: "";
        readonly donationUrl: null;
        readonly description: {
            readonly short: "";
            readonly long: "";
        };
        readonly images: {
            readonly main: {
                readonly source: {
                    readonly dockerTag: "start9/hello-world";
                };
                readonly arch: ["aarch64", "x86_64"];
                readonly emulateMissing: true;
            };
        };
        readonly volumes: [];
    }>;
};
