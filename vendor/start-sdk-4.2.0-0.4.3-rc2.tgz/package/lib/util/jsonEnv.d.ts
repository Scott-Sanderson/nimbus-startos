/** Encodes command variables in numbered UTF-8 JSON chunks. */
export declare function jsonEnv(environment: Record<string, string | null | undefined>): NodeJS.ProcessEnv;
