import * as fs from 'fs/promises';
import * as T from '@start9labs/start-core/types';
import * as cp from 'child_process';
import { Buffer } from 'node:buffer';
import { Drop } from '@start9labs/start-core/util/Drop';
import { Mounts } from '../mainFn/Mounts';
export declare const execFile: typeof cp.execFile.__promisify__;
export type ExecOptions = {
    input?: string | Buffer;
    /** How long to wait before SIGKILL, in ms (default 30000). `null` waits as long as the command takes — use it whenever the runtime is set by the size of the data or the speed of a disk. */
    timeout?: number | null;
    /** Aborting SIGKILLs the process */
    abort?: AbortController;
};
/**
 * Isolated container environment for running service processes.
 *
 * Two concrete shapes implement this interface:
 *
 * - {@link SubContainerEager} — created and materialized immediately by
 *   {@link SubContainer.eager}. The `rootfs` / `guid` / `subpath()` accessors
 *   return `string` / `T.Guid` synchronously.
 * - {@link SubContainerLazy} — created by {@link SubContainer.of} (the
 *   default). Backing filesystem is not materialized until the first method
 *   call (or explicit {@link SubContainerLazy.eager}). `rootfs` / `guid` /
 *   `subpath()` return `Promise<...>`.
 *
 * The interface widens those accessors to `T | Promise<T>` so a caller
 * holding the interface type must `await` (which yields the value for either
 * shape). Callers holding the concrete class get the narrower sync type.
 *
 * ### Lifecycle and sharing
 *
 * Multiple consumers may share a single SubContainer (typical pattern: an
 * `Oneshot` setup step and a `Daemon` running in the same container so the
 * setup's writes are visible to the daemon). Each consumer takes a use-hold
 * via {@link SubContainer.hold} and releases it when finished. The
 * SubContainer is torn down (`destroyFs`) when {@link SubContainer.destroy}
 * has been called *and* all outstanding holds have been released — whichever
 * is later. `Daemons` manages holds for the daemons it owns.
 */
export interface SubContainer<Manifest extends T.SDKManifest, Effects extends T.Effects = T.Effects> extends Drop {
    /** The image this subcontainer is launched from. */
    readonly imageId: keyof Manifest['images'] & T.ImageId;
    /**
     * Stable, sync handle identifying this SubContainer. Generated at
     * construction by {@link SubContainer.of} / {@link SubContainer.eager}
     * and preserved across materialization, so a lazy handle and the eager
     * it materializes into compare equal. Use this for sharing comparisons
     * that must work pre-materialization.
     */
    readonly identity: symbol;
    /**
     * Absolute path to the subcontainer's rootfs. Sync `string` on
     * {@link SubContainerEager}; `Promise<string>` on
     * {@link SubContainerLazy}. Awaiting the property works for either.
     */
    readonly rootfs: string | Promise<string>;
    /**
     * OS-level guid of the subcontainer. Sync `T.Guid` on
     * {@link SubContainerEager}; `Promise<T.Guid>` on
     * {@link SubContainerLazy}.
     */
    readonly guid: T.Guid | Promise<T.Guid>;
    /**
     * Get the absolute path to a file or directory within this subcontainer's rootfs.
     * Sync `string` on {@link SubContainerEager}; `Promise<string>` on
     * {@link SubContainerLazy} (resolves after first materialization).
     * @param path Path relative to the rootfs
     */
    subpath(path: string): string | Promise<string>;
    /**
     * Apply filesystem mounts (volumes, assets, dependencies) to this subcontainer.
     * Lazy handles materialize on this call.
     * @param mounts - The Mounts configuration to apply
     * @returns This subcontainer instance for chaining
     */
    mount(mounts: Mounts<Manifest>): Promise<this>;
    /**
     * Try an optional shared-volume mount; start the affected workload only when mounted.
     * Requires manifest opt-in and a user grant. Authorization and invalid-path failures reject.
     */
    tryMountSharedVolume(options: SharedVolumeMountOptions): Promise<T.SharedVolumeMountResult>;
    /**
     * Take a use-hold on this subcontainer. The returned function releases
     * the hold; the SubContainer is destroyed when {@link destroy} has been
     * called *and* the last hold is released, in either order.
     *
     * @returns A release function — call it to drop this hold
     */
    hold(): () => Promise<void>;
    /**
     * Mark this subcontainer for destruction. Fires `destroyFs` immediately
     * if no holds are outstanding; otherwise the final hold-release fires
     * it. Idempotent.
     */
    destroy(): Promise<void>;
    /**
     * Detach this subcontainer from the effects context that created it, so it
     * is *not* destroyed when that context leaves (`onLeaveContext`). Use when a
     * short-lived context — e.g. an action — launches work that must outlive it;
     * after detaching, the caller owns the subcontainer's lifecycle and must
     * call {@link destroy} explicitly. Idempotent; does not affect holds or a
     * pending {@link destroy}.
     */
    detach(): void;
    /**
     * @description run a command inside this subcontainer
     * DOES NOT THROW ON NONZERO EXIT CODE (see execFail)
     * @param command an array representing the command and args to execute
     * @param options env, cwd, user, stdin, `timeout` (default 30 s, `null` for no timeout), and `abort`
     * @returns
     */
    exec(command: string[], options?: CommandOptions & ExecOptions): Promise<{
        throw: () => {
            stdout: string | Buffer;
            stderr: string | Buffer;
        };
        exitCode: number | null;
        exitSignal: NodeJS.Signals | null;
        timedOutAfter: number | null;
        stdout: string | Buffer;
        stderr: string | Buffer;
    }>;
    /**
     * @description run a command inside this subcontainer, throwing on non-zero exit status
     * @param command an array representing the command and args to execute
     * @param options env, cwd, user, stdin, `timeout` (default 30 s, `null` for no timeout), and `abort`
     * @returns
     * @throws {@link ExitError} on non-zero exit code or signal termination
     */
    execFail(command: string[], options?: CommandOptions & ExecOptions): Promise<{
        stdout: string | Buffer;
        stderr: string | Buffer;
    }>;
    /**
     * Launch a command as the init (PID 1) process of the subcontainer.
     * Replaces the current leader process.
     * @param command - The command and arguments to execute
     * @param options - Optional environment, working directory, and user overrides
     */
    launch(command: string[], options?: CommandOptions): Promise<cp.ChildProcessWithoutNullStreams>;
    /**
     * Spawn a command inside the subcontainer as a non-init process.
     * @param command - The command and arguments to execute
     * @param options - Optional environment, working directory, user, and stdio overrides
     */
    spawn(command: string[], options?: CommandOptions & StdioOptions): Promise<cp.ChildProcess>;
    /**
     * @description Write a file to the subcontainer's filesystem
     * @param path Path relative to the subcontainer rootfs (e.g. "/etc/config.json")
     * @param data The data to write
     * @param options Optional write options (same as node:fs/promises writeFile)
     */
    writeFile(path: string, data: string | NodeJS.ArrayBufferView | Iterable<string | NodeJS.ArrayBufferView> | AsyncIterable<string | NodeJS.ArrayBufferView>, options?: Parameters<typeof fs.writeFile>[2]): Promise<void>;
}
/**
 * Top-level factories for creating SubContainers. Prefer
 * {@link SubContainer.of} (lazy) unless you need synchronous access to
 * `rootfs` / `guid` / `subpath()` before running any methods — for that, use
 * {@link SubContainer.eager}.
 */
export declare const SubContainer: {
    /**
     * Create a {@link SubContainerLazy} that materializes its backing
     * filesystem on first use. Synchronous return — no `Promise` wrapper.
     *
     * Identity is generated at this call and threaded through to the eager
     * container produced by {@link SubContainerLazy.eager}.
     *
     * This is the default factory. Use it whenever the subcontainer might
     * not actually be needed (the canonical case: `Daemons.dynamic` may diff
     * a daemon away before it ever runs) and whenever you don't need sync
     * access to `rootfs` / `guid` / `subpath()`.
     *
     * @param effects The effects context the subcontainer will run under
     * @param image Image to launch from (must be declared in the manifest); `sharedRun` rbinds the host's `/run` if true
     * @param mounts Initial mounts applied at materialization (declared so they participate in `Daemons.dynamic`'s `configHash`)
     * @param name Debug/identification name (does not affect identity)
     */
    of<Manifest extends T.SDKManifest, Effects extends T.Effects = T.Effects>(effects: Effects, image: {
        imageId: keyof Manifest["images"] & T.ImageId;
        sharedRun?: boolean;
    }, mounts: Mounts<Manifest> | null, name: string): SubContainerLazy<Manifest, Effects>;
    /**
     * Create a {@link SubContainerEager}, materializing the backing
     * filesystem immediately. Returns `Promise<SubContainerEager>`.
     *
     * Use when you need synchronous access to `rootfs` / `guid` /
     * `subpath()` before running any methods (e.g. mounting paths from
     * outside the container, init-time precheck), or when you want
     * `effects.subcontainer.createFs` failures to surface here instead of at
     * first method call.
     *
     * **Do not pass an eager SubContainer to `Daemons.dynamic`'s `fn`**.
     * Eager handles created inside `fn` are wasted on re-runs that diff to
     * "leave alone" — use {@link SubContainer.of} (lazy) for daemons under
     * `Daemons.dynamic`.
     *
     * @param effects The effects context the subcontainer will run under
     * @param image Image to launch from; `sharedRun` rbinds the host's `/run` if true
     * @param mounts Mounts applied during construction
     * @param name Debug/identification name (does not affect identity)
     */
    eager<Manifest extends T.SDKManifest, Effects extends T.Effects = T.Effects>(effects: Effects, image: {
        imageId: keyof Manifest["images"] & T.ImageId;
        sharedRun?: boolean;
    }, mounts: Mounts<Manifest> | null, name: string): Promise<SubContainerEager<Manifest, Effects>>;
    /**
     * Run a function with an ephemeral, eager subcontainer. The container
     * is created before `fn` runs and destroyed in a `finally` block after.
     * Use for one-off command execution that needs a fresh filesystem.
     *
     * @param effects The effects context the subcontainer will run under
     * @param image Image to launch from; `sharedRun` rbinds the host's `/run` if true
     * @param mounts Mounts applied during construction
     * @param name Debug/identification name (does not affect identity)
     * @param fn Function to invoke with the eager subcontainer
     * @returns Whatever `fn` returns
     */
    withTemp<Manifest extends T.SDKManifest, T_, Effects extends T.Effects = T.Effects>(effects: Effects, image: {
        imageId: keyof Manifest["images"] & T.ImageId;
        sharedRun?: boolean;
    }, mounts: Mounts<Manifest> | null, name: string, fn: (sub: SubContainerEager<Manifest, Effects>) => Promise<T_>): Promise<T_>;
};
/**
 * Want to limit what we can do in a container, so we want to launch a container with a specific image and the mounts.
 *
 * Eager subcontainer: its filesystem and leader process exist from
 * construction. `rootfs` / `guid` / `subpath()` are synchronous.
 *
 * Construct via {@link SubContainer.eager} or {@link SubContainer.withTemp}.
 */
export declare class SubContainerEager<Manifest extends T.SDKManifest, Effects extends T.Effects = T.Effects> extends Drop implements SubContainer<Manifest, Effects> {
    readonly effects: Effects;
    readonly imageId: keyof Manifest['images'] & T.ImageId;
    readonly rootfs: string;
    readonly guid: T.Guid;
    readonly identity: symbol;
    private destroyed;
    private destroyRequested;
    private holdCount;
    private teardown;
    private readonly fileMounts;
    private sharedMounts;
    private sharedVolumeDependency;
    private leader;
    private leaderExited;
    private waitProc;
    private constructor();
    /**
     * Internal factory preserving a lazy handle's identity.
     * The creation hook runs before mounting, while context ownership can still change.
     * External callers use {@link SubContainer.eager} or {@link SubContainer.of}.
     */
    static _of<Manifest extends T.SDKManifest, Effects extends T.Effects>(effects: Effects, image: {
        imageId: keyof Manifest['images'] & T.ImageId;
        sharedRun?: boolean;
    }, mounts: Mounts<Manifest> | null, name: string, identity: symbol, onCreate?: (sub: SubContainerEager<Manifest, Effects>) => void): Promise<SubContainerEager<Manifest, Effects>>;
    /**
     * Resolve a path within this subcontainer's rootfs (synchronous on eager).
     *
     * @param path Path relative to the rootfs (e.g. `"/etc/config.json"` or `"data/file"`)
     */
    subpath(path: string): string;
    /**
     * Apply filesystem mounts (volumes, assets, dependencies) to
     * this subcontainer.
     *
     * @param mounts The Mounts configuration to apply
     * @returns This subcontainer instance for chaining
     */
    mount(mounts: Mounts<Manifest>): Promise<this>;
    /** @internal Includes unsuccessful optional shared-volume mount attempts. */
    get dependsOnSharedVolumes(): boolean;
    /**
     * Try an optional shared-volume mount. Only source unavailability returns an outcome;
     * authorization, invalid paths, and internal failures reject.
     */
    tryMountSharedVolume(options: SharedVolumeMountOptions): Promise<T.SharedVolumeMountResult>;
    /**
     * Take a use-hold on this subcontainer. The container is destroyed
     * when {@link destroy} has been called *and* the last hold is released,
     * in either order.
     *
     * @returns A release function — call it to drop this hold
     * @throws If this subcontainer has already been destroyed
     */
    hold(): () => Promise<void>;
    /**
     * Mark this subcontainer for destruction. Fires `destroyFs` immediately
     * if no holds are outstanding; otherwise the final hold-release fires
     * it. Idempotent.
     */
    destroy(): Promise<void>;
    /**
     * Detach from the creating context's `onLeaveContext` cleanup — drops this
     * subcontainer from its context's live set so a context-leave no longer
     * destroys it. The caller becomes responsible for calling {@link destroy}.
     * Idempotent.
     */
    detach(): void;
    private _destroyImmediate;
    private killLeader;
    onDrop(): void;
    /**
     * Run a command inside this subcontainer.
     * Does NOT throw on non-zero exit (see {@link execFail}).
     * Timeout and cancellation close output pipes; captured output may be incomplete.
     * A command that already exited retains its exit status.
     *
     * @param command Argv array representing the command and its arguments
     * @param options Optional environment, user, cwd, stdin input, `timeout` (default 30 s, `null` for no timeout), and `abort`
     */
    exec(command: string[], options?: CommandOptions & ExecOptions): Promise<{
        throw: () => {
            stdout: string | Buffer;
            stderr: string | Buffer;
        };
        exitCode: number | null;
        exitSignal: NodeJS.Signals | null;
        timedOutAfter: number | null;
        stdout: string | Buffer;
        stderr: string | Buffer;
    }>;
    /**
     * Run a command inside this subcontainer, throwing on non-zero exit.
     *
     * @param command Argv array representing the command and its arguments
     * @param options Optional environment, user, cwd, stdin input, `timeout` (default 30 s, `null` for no timeout), and `abort`
     * @throws {@link ExitError} on non-zero exit code or signal termination
     */
    execFail(command: string[], options?: CommandOptions & ExecOptions): Promise<{
        stdout: string | Buffer;
        stderr: string | Buffer;
    }>;
    /**
     * Launch a command as the init (PID 1) process of the subcontainer.
     * Replaces the current leader process.
     *
     * @param command Argv array representing the command and its arguments
     * @param options Optional environment, working directory, and user overrides
     */
    launch(command: string[], options?: CommandOptions): Promise<cp.ChildProcessWithoutNullStreams>;
    /**
     * Spawn a command inside the subcontainer as a non-init process.
     *
     * @param command Argv array representing the command and its arguments
     * @param options Optional environment, working directory, user, and stdio overrides
     */
    spawn(command: string[], options?: CommandOptions & StdioOptions): Promise<cp.ChildProcess>;
    /**
     * Write a file to the subcontainer's filesystem.
     *
     * @param path Path relative to the subcontainer rootfs (e.g. `"/etc/config.json"`)
     * @param data The data to write
     * @param options Optional write options (same as `node:fs/promises` `writeFile`)
     */
    writeFile(path: string, data: string | NodeJS.ArrayBufferView | Iterable<string | NodeJS.ArrayBufferView> | AsyncIterable<string | NodeJS.ArrayBufferView>, options?: Parameters<typeof fs.writeFile>[2]): Promise<void>;
}
/**
 * Lazy subcontainer: a handle whose backing filesystem is materialized on
 * first use (or explicit {@link SubContainerLazy.eager}). The narrow types
 * for `rootfs` / `guid` / `subpath()` are `Promise<...>`.
 *
 * Construct via {@link SubContainer.of}. Identity is generated at
 * construction and preserved across materialization.
 *
 * Sharing across consumers: pass the same `SubContainerLazy` to multiple
 * `addDaemon` calls. The first consumer to call a method (or `.eager()`)
 * triggers materialization; all consumers end up holding the same
 * underlying {@link SubContainerEager}.
 */
export declare class SubContainerLazy<Manifest extends T.SDKManifest, Effects extends T.Effects = T.Effects> extends Drop implements SubContainer<Manifest, Effects> {
    readonly effects: Effects;
    readonly identity: symbol;
    readonly imageId: keyof Manifest['images'] & T.ImageId;
    readonly sharedRun: boolean;
    readonly name: string;
    /** The mounts declared at construction. Read by `Daemons.dynamic`'s configHash. */
    readonly mounts: Mounts<Manifest> | null;
    /** @internal Declared or attempted shared-volume dependencies of this container. */
    get dependsOnSharedVolumes(): boolean;
    private materialized;
    private created;
    private destroyRequested;
    private detachRequested;
    private holds;
    constructor(effects: Effects, image: {
        imageId: keyof Manifest['images'] & T.ImageId;
        sharedRun?: boolean;
    }, mounts: Mounts<Manifest> | null, name: string);
    /**
     * Materialize the underlying eager subcontainer and return it. Concurrent
     * calls share one attempt; successful materialization is cached, while a
     * failed attempt is logged and retried by the next call. Useful when you
     * need the synchronous `SubContainerEager` interface (e.g. sync `rootfs` /
     * `subpath()`) — for ordinary command execution, just call `.exec()` /
     * `.writeFile()` directly and the lazy handle materializes internally.
     */
    eager(): Promise<SubContainerEager<Manifest, Effects>>;
    /** Absolute path to the materialized subcontainer's rootfs. Triggers materialization on first access. */
    get rootfs(): Promise<string>;
    /** OS-level guid. Triggers materialization on first access. */
    get guid(): Promise<T.Guid>;
    /**
     * Resolve a path within the subcontainer's rootfs. Triggers
     * materialization on first call.
     *
     * @param path Path relative to the rootfs
     */
    subpath(path: string): Promise<string>;
    /**
     * Apply filesystem mounts to this subcontainer (materializes on first
     * call). Mounts beyond the ones declared at construction are not part
     * of `Daemons.dynamic`'s `configHash`.
     *
     * @param mounts The Mounts configuration to apply
     * @returns This lazy handle, for chaining
     */
    mount(mounts: Mounts<Manifest>): Promise<this>;
    /** Try an optional shared-volume mount, materializing this subcontainer on first use. */
    tryMountSharedVolume(options: SharedVolumeMountOptions): Promise<T.SharedVolumeMountResult>;
    /**
     * Take a use-hold on this subcontainer. Materializes the underlying
     * eager subcontainer asynchronously and places the hold on it.
     *
     * The returned release function is safe to call before materialization
     * completes; it cancels the pending hold. Failed materializations keep the
     * hold pending for the next attempt.
     *
     * @returns A release function — call it to drop this hold
     */
    hold(): () => Promise<void>;
    /**
     * Mark this subcontainer for destruction. If already materialized, the
     * underlying eager's destroy is invoked (which respects outstanding
     * holds), after any materialization in flight. Otherwise the request is
     * recorded and applied on materialization.
     */
    destroy(): Promise<void>;
    /**
     * Detach from the creating context's `onLeaveContext` cleanup, including
     * during materialization. The caller owns teardown through {@link destroy}.
     * Idempotent.
     */
    detach(): void;
    /**
     * Run a command inside this subcontainer (materializes on first call).
     * Does NOT throw on non-zero exit (see {@link execFail}).
     *
     * @param command Argv array representing the command and its arguments
     * @param options Optional environment, user, cwd, stdin input, `timeout` (default 30 s, `null` for no timeout), and `abort`
     */
    exec(command: string[], options?: CommandOptions & ExecOptions): Promise<{
        throw: () => {
            stdout: string | Buffer;
            stderr: string | Buffer;
        };
        exitCode: number | null;
        exitSignal: NodeJS.Signals | null;
        timedOutAfter: number | null;
        stdout: string | Buffer;
        stderr: string | Buffer;
    }>;
    /**
     * Run a command inside this subcontainer, throwing on non-zero exit
     * (materializes on first call).
     *
     * @param command Argv array representing the command and its arguments
     * @param options Optional environment, user, cwd, stdin input, `timeout` (default 30 s, `null` for no timeout), and `abort`
     * @throws {@link ExitError} on non-zero exit code or signal termination
     */
    execFail(command: string[], options?: CommandOptions & ExecOptions): Promise<{
        stdout: string | Buffer;
        stderr: string | Buffer;
    }>;
    /**
     * Launch a command as the init (PID 1) process of the subcontainer
     * (materializes on first call).
     *
     * @param command Argv array representing the command and its arguments
     * @param options Optional environment, working directory, and user overrides
     */
    launch(command: string[], options?: CommandOptions): Promise<cp.ChildProcessWithoutNullStreams>;
    /**
     * Spawn a command inside the subcontainer as a non-init process
     * (materializes on first call).
     *
     * @param command Argv array representing the command and its arguments
     * @param options Optional environment, working directory, user, and stdio overrides
     */
    spawn(command: string[], options?: CommandOptions & StdioOptions): Promise<cp.ChildProcess>;
    /**
     * Write a file to the subcontainer's filesystem (materializes on first call).
     *
     * @param path Path relative to the subcontainer rootfs (e.g. `"/etc/config.json"`)
     * @param data The data to write
     * @param options Optional write options (same as `node:fs/promises` `writeFile`)
     */
    writeFile(path: string, data: string | NodeJS.ArrayBufferView | Iterable<string | NodeJS.ArrayBufferView> | AsyncIterable<string | NodeJS.ArrayBufferView>, options?: Parameters<typeof fs.writeFile>[2]): Promise<void>;
    onDrop(): void;
}
export type CommandOptions = {
    /** Environment variables to set for this command; `undefined` unsets one */
    env?: {
        [variable in string]?: string;
    };
    /** the working directory to run this command in */
    cwd?: string;
    /** the user to run this command as */
    user?: string;
};
export type StdioOptions = {
    stdio?: cp.StdioOptions;
};
/** UID/GID mapping for mount id-remapping (see kernel idmappings docs) */
export type IdMap = {
    fromId: number;
    toId: number;
    range: number;
};
/** Union of all mount option types supported by the subcontainer runtime */
export type MountOptions = MountOptionsVolume | MountOptionsAssets | MountOptionsPointer | MountOptionsShared;
/** A shared-volume directory mount. Names are editable; select by the granted ID. */
export type SharedVolumeMountOptions = Omit<Parameters<T.Effects['mountSharedVolume']>[0], 'subcontainer'>;
/** An essential shared-volume mount declared by `Mounts`. */
export type MountOptionsShared = Omit<SharedVolumeMountOptions, 'mountpoint'> & {
    type: 'shared';
};
/** Mount options for binding a service volume into a subcontainer */
export type MountOptionsVolume = {
    type: 'volume';
    volumeId: string;
    subpath: string | null;
    readonly: boolean;
    filetype: 'file' | 'directory' | 'infer';
    idmap: IdMap[];
};
/** Mount options for binding packaged static assets into a subcontainer */
export type MountOptionsAssets = {
    type: 'assets';
    subpath: string | null;
    filetype: 'file' | 'directory' | 'infer';
    idmap: {
        fromId: number;
        toId: number;
        range: number;
    }[];
};
/** Mount options for binding a dependency package's volume into a subcontainer */
export type MountOptionsPointer = {
    type: 'pointer';
    packageId: string;
    volumeId: string;
    subpath: string | null;
    readonly: boolean;
    idmap: {
        fromId: number;
        toId: number;
        range: number;
    }[];
};
/**
 * Error thrown when a subcontainer command exits with a non-zero code or
 * signal. Contains the full result including stdout, stderr, exit code,
 * and exit signal.
 */
export declare class ExitError extends Error {
    readonly command: string;
    readonly result: {
        exitCode: number | null;
        exitSignal: T.Signals | null;
        timedOutAfter: number | null;
        stdout: string | Buffer;
        stderr: string | Buffer;
    };
    constructor(command: string, result: {
        exitCode: number | null;
        exitSignal: T.Signals | null;
        timedOutAfter: number | null;
        stdout: string | Buffer;
        stderr: string | Buffer;
    });
}
