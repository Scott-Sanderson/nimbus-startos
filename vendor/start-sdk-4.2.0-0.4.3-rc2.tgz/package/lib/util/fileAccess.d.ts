export declare const UPDATE_TIMEOUT_MS = 5000;
export declare const LOCK_TIMEOUT_MS = 10000;
export declare function waitForFileOperation<A>(pending: Promise<A>, signal: AbortSignal): Promise<A>;
export declare function filePath(path: string): Promise<string>;
/** Runs without inheriting the caller's file locks. */
export declare function outsideFileLocks<A>(operation: () => A): A;
/** Serializes access within this process; reentrant for the holder. */
export declare function withFileQueue<A>(path: string, operation: (path: string, signal: AbortSignal) => Promise<A>): Promise<A>;
/** Aborts the callback, and all file access it starts, after `UPDATE_TIMEOUT_MS`. */
export declare function withUpdateDeadline<A>(target: string, signal: AbortSignal, callback: () => A | Promise<A>): Promise<A>;
/** The supplied temp must become the missing target. */
export declare function withFileLock<A>(path: string, operation: (path: string, temp: string | undefined, signal: AbortSignal) => Promise<A>): Promise<A>;
/** Persists an exclusive backup before callers may replace the source. */
export declare function copyFileBackup(source: string, backup: string, signal: AbortSignal): Promise<void>;
export declare function replaceFile(path: string, data: string, lockedTemp: string | undefined, signal: AbortSignal): Promise<void>;
