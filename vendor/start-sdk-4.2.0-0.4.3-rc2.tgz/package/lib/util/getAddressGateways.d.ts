import { Effects, GatewayId, HostId } from '@start9labs/start-core/types';
/** Result of {@link getAddressGateways}. */
export type AddressGateways = {
    /** The gateway this service's outbound connections leave through. */
    outbound: GatewayId;
    /** Each address passed in, with the gateway publishing it, or `null` when no gateway publishes it. */
    addresses: {
        address: string;
        gateway: GatewayId | null;
    }[];
};
/**
 * Resolve the gateways publishing a service's advertised addresses, beside the
 * gateway its outbound connections leave through.
 *
 * Pass the addresses the service actually advertises or authorizes, read back
 * from its rendered configuration. Equal gateways establish gateway
 * consistency only: outbound traffic may still carry a different source
 * address of the same gateway. Each call reads both values once, so a health
 * check may call it on every poll.
 *
 * @param effects - The effects context
 * @param hostId - The host whose bindings publish the addresses
 * @param addresses - IP literals or domains the service advertises
 */
export declare function getAddressGateways(effects: Effects, hostId: HostId, addresses: string[]): Promise<AddressGateways>;
