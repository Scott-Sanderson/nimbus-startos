export declare function hasFileMounts(path: string): boolean;
/** The caller must hold the source's `withFileQueue` through refresh. */
export declare function refreshFileMounts(path: string, signal: AbortSignal): Promise<void>;
export declare class FileMounts {
    private readonly registrations;
    add(source: string, target: string, rebind: (signal: AbortSignal) => Promise<void>): Promise<void>;
    sync(): Promise<void>;
    close(): Promise<void>;
}
