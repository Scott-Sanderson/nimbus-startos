import { type X2jOptions, type XmlBuilderOptions } from 'fast-xml-parser';
import * as INI from 'ini';
import * as YAML from 'yaml';
import * as z from '@start9labs/start-core/z';
import * as T from '@start9labs/start-core/types';
import { PathBase } from './Volume';
/**
 * Maps between the parsed file format and the schema's input.
 *
 * @typeParam Raw - The value the file format parses to
 * @typeParam Transformed - The value the schema validates
 */
export type Transformers<Raw = unknown, Transformed = unknown, Validated extends Transformed = Transformed> = {
    /** Converts the parsed file into the schema's input. */
    onRead: (value: Raw) => Transformed;
    /** Converts validated data into the value the file format serializes. */
    onWrite: (value: Validated) => Raw;
};
type ToPath = string | {
    base: PathBase;
    subpath: string;
};
type Validator<_T, U> = z.ZodType<U>;
type ReadType<A> = {
    once: () => Promise<A | null>;
    const: (effects: T.Effects) => Promise<A | null>;
    watch: (effects: T.Effects, abort?: AbortSignal) => AsyncGenerator<A | null, never, unknown>;
    onChange: (effects: T.Effects, callback: (value: A | null, error?: Error) => {
        cancel: boolean;
    } | Promise<{
        cancel: boolean;
    }>) => void;
    waitFor: (effects: T.Effects, pred: (value: A | null) => boolean, abort?: AbortSignal) => Promise<A | null>;
};
/**
 * A validated file with reactive reads and serialized writes.
 *
 * The schema mirrors the file: a value the upstream service does not require is
 * optional, even where the package always sets it. Give every key a `.catch()`
 * default, so a hand-edited value of the wrong type falls back to it. Build it
 * with `z.looseObject` at every level: `z.object` deletes every key it does not
 * declare on the next write.
 *
 * @example
 * ```ts
 * import { FileHelper, z } from '@start9labs/start-sdk'
 *
 * export const configToml = FileHelper.toml(
 *   { base: sdk.volumes.main, subpath: 'config.toml' },
 *   z.looseObject({
 *     port: z.number().catch(8080),
 *     allow_registration: z.boolean().catch(false),
 *   }),
 * )
 * ```
 */
export interface FileHelper<A> {
    readonly path: string;
    readonly writeData: (dataIn: A) => string;
    readonly readData: (stringValue: string) => unknown;
    readonly validate: (value: unknown) => A;
    /**
     * Creates a reactive reader for this file.
     *
     * - `once()` - Reads the file once
     * - `const(effects)` - Reads once and re-runs the enclosing context when the value changes
     * - `watch(effects)` - Yields the value on each change
     * - `onChange(effects, callback)` - Calls back on each change
     * - `waitFor(effects, predicate, abort?)` - Resolves once the value satisfies the predicate
     *
     * @param map - Transforms the validated value
     * @param eq - Deduplicates emissions of the mapped value
     */
    read(): ReadType<A>;
    read<B>(map: (value: A) => B, eq?: (left: B | null, right: B | null) => boolean): ReadType<B>;
    /** Replaces the file with validated data; bind-mounted targets are written in place. */
    write(effects: T.Effects, data: T.AllowReadonly<A> | A, options?: {
        allowWriteAfterConst?: boolean;
    }): Promise<null>;
    /**
     * Deep-merges partial data under the writer lock; arrays are replaced.
     * Invalid file syntax falls back to schema defaults, after the file is copied
     * durably to `<path>.unparseable-<timestamp>`.
     * Backup or transformer errors reject.
     */
    merge(effects: T.Effects, data: T.AllowReadonly<T.DeepPartial<A>>, options?: {
        allowWriteAfterConst?: boolean;
    }): Promise<null>;
    /**
     * Replaces the file with the callback's result under the writer lock.
     * Returning `null` skips the write. The callback has five seconds; nested
     * mutations of the same file reject.
     */
    update(effects: T.Effects, change: (current: A | null) => T.AllowReadonly<A> | null | Promise<T.AllowReadonly<A> | null>, options?: {
        allowWriteAfterConst?: boolean;
    }): Promise<null>;
    /** Returns a helper with the same format and schema at another path. */
    withPath(path: ToPath): FileHelper<A>;
}
interface FileHelperStatic {
    /** Creates a FileHelper for a custom format. */
    raw<A>(path: ToPath, toFile: (dataIn: A) => string, fromFile: (rawData: string) => unknown, validate: (data: unknown) => A): FileHelper<A>;
    /** Creates a FileHelper for a text file. */
    string(path: ToPath): FileHelper<string>;
    string<A extends string>(path: ToPath, shape: Validator<string, A>): FileHelper<A>;
    string<A extends Transformed, Transformed = string>(path: ToPath, shape: Validator<Transformed, A>, transformers: Transformers<string, Transformed, A>): FileHelper<A>;
    /** Creates a FileHelper for a JSON file. */
    json<A>(path: ToPath, shape: Validator<unknown, A>): FileHelper<A>;
    json<A extends Transformed, Transformed = unknown>(path: ToPath, shape: Validator<unknown, A>, transformers: Transformers<unknown, Transformed, A>): FileHelper<A>;
    /** Creates a FileHelper for a YAML file. */
    yaml<A extends Record<string, unknown>>(path: ToPath, shape: Validator<Record<string, unknown>, A>, options?: YAML.ParseOptions & YAML.DocumentOptions & YAML.SchemaOptions & YAML.ToJSOptions & YAML.CreateNodeOptions & YAML.ToStringOptions): FileHelper<A>;
    yaml<A extends Transformed, Transformed = Record<string, unknown>>(path: ToPath, shape: Validator<Transformed, A>, options: YAML.ParseOptions & YAML.DocumentOptions & YAML.SchemaOptions & YAML.ToJSOptions & YAML.CreateNodeOptions & YAML.ToStringOptions, transformers: Transformers<Record<string, unknown>, Transformed, A>): FileHelper<A>;
    /** Creates a FileHelper for a TOML file. */
    toml<A extends Record<string, unknown>>(path: ToPath, shape: Validator<Record<string, unknown>, A>): FileHelper<A>;
    toml<A extends Transformed, Transformed = Record<string, unknown>>(path: ToPath, shape: Validator<Transformed, A>, transformers: Transformers<Record<string, unknown>, Transformed, A>): FileHelper<A>;
    /** Creates a FileHelper for an INI file. */
    ini<A extends Record<string, unknown>>(path: ToPath, shape: Validator<Record<string, unknown>, A>, options?: INI.EncodeOptions & INI.DecodeOptions): FileHelper<A>;
    ini<A extends Transformed, Transformed = Record<string, unknown>>(path: ToPath, shape: Validator<Transformed, A>, options: INI.EncodeOptions & INI.DecodeOptions, transformers: Transformers<Record<string, unknown>, Transformed, A>): FileHelper<A>;
    /** Creates a FileHelper for a .env file of `KEY=VALUE` lines. */
    env<A extends Record<string, string>>(path: ToPath, shape: Validator<Record<string, string>, A>): FileHelper<A>;
    env<A extends Transformed, Transformed = Record<string, string>>(path: ToPath, shape: Validator<Transformed, A>, transformers: Transformers<Record<string, string>, Transformed, A>): FileHelper<A>;
    /** Creates a FileHelper for an XML file. */
    xml<A extends Record<string, unknown>>(path: ToPath, shape: Validator<Record<string, unknown>, A>, options?: {
        parser?: X2jOptions;
        builder?: XmlBuilderOptions;
    }): FileHelper<A>;
    xml<A extends Transformed, Transformed = Record<string, unknown>>(path: ToPath, shape: Validator<Transformed, A>, options: {
        parser?: X2jOptions;
        builder?: XmlBuilderOptions;
    }, transformers: Transformers<Record<string, unknown>, Transformed, A>): FileHelper<A>;
}
export declare const FileHelper: FileHelperStatic;
export default FileHelper;
