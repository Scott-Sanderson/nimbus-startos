import type { Effects, DependencyRequirement, Manifest, LocaleString } from '@start9labs/start-core/types';
import type { InitKind, InitScript, InitScriptOrFn } from '@start9labs/start-core/inits/setupInit';
import { FullProgressTracker } from '@start9labs/start-core/util/FullProgressTracker';
type Base = {
    description: LocaleString | null;
    metadata: {
        title: LocaleString;
        icon: string;
    };
    versionRange: string;
} & ({
    kind: 'running';
    healthChecks: string[];
} | {
    kind: 'exists';
    healthChecks?: never;
});
type Narrowing = {
    versionRange?: string;
    kind?: 'running';
    healthChecks?: string[];
};
/** A published base requirement with optional reactive runtime restrictions. */
export declare class Dependency<Id extends string = string> {
    readonly id: Id;
    readonly optional: boolean;
    readonly base: Base;
    private narrowing?;
    private readonly inits;
    private enabledFn?;
    private constructor();
    /** Publishes a requirement that is always active. */
    static required<const Id extends string>(id: Id, base: Base): Dependency<Id>;
    /** Publishes a requirement activated by the service's configuration. */
    static optional<const Id extends string>(id: Id, base: Base & {
        enabled: (options: {
            effects: Effects;
        }) => Promise<boolean>;
    }): Dependency<Id>;
    /** Restricts the published requirement for the active configuration. */
    withDynamicNarrowing(fn: (options: {
        effects: Effects;
    }) => Promise<Narrowing | null>): this;
    /** Appends an independent reactive init, run while the dependency is enabled. */
    withInit(fn: InitScriptOrFn): this;
    enabled(effects: Effects): Promise<boolean>;
    initHandlers(): readonly InitScript[];
    manifestInfo(): Manifest['dependencies'][string];
    /** The runtime requirement while enabled. */
    requirement(effects: Effects): Promise<DependencyRequirement>;
}
/** A single dependency definition for the manifest and runtime. */
export declare class Dependencies<Ids extends string = never> implements InitScript {
    private readonly entries;
    private constructor();
    static of(): Dependencies<never>;
    addDependency<const Id extends string>(dependency: Dependency<Id>): Dependencies<Ids | Id>;
    /** The dependency metadata embedded in the package manifest. */
    manifestDependencies(): Manifest['dependencies'];
    init(effects: Effects, kind?: InitKind, progress?: FullProgressTracker): Promise<void>;
    /** Checks the active runtime requirements. */
    check(effects: Effects, packageIds?: Ids[]): Promise<import("@start9labs/start-core/dependencies/dependencies").CheckDependencies<Ids>>;
}
export {};
