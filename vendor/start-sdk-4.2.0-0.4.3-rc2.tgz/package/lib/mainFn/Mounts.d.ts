import * as T from '@start9labs/start-core/types';
import { MountOptions, SharedVolumeMountOptions } from '../util/SubContainer';
type MountArray = {
    mountpoint: string;
    options: MountOptions;
}[];
type SharedOptions = {
    /** The path within the resource to mount. Use `null` to mount the entire resource */
    subpath: string | null;
    /** Where to mount the resource. e.g. /data */
    mountpoint: string;
    /**
     * Whether to mount this as a file or directory
     *
     * defaults to "directory"
     * */
    type?: 'file' | 'directory' | 'infer';
    /**
     * Optional UID/GID remapping for the mount, written from the
     * perspective of this container — `fromId` is the id seen on the
     * filesystem and `toId` is the id mounted processes see. The base
     * LXC mapping is applied automatically; do not include it here.
     *
     * https://www.kernel.org/doc/html/latest/filesystems/idmappings.html
     */
    idmap?: {
        /** The (starting) id of the data on the filesystem (u) */
        fromId: number;
        /** The (starting) id of the data in the mount point (k) */
        toId: number;
        /**
         * Optional: the number of incremental ids to map (r)
         *
         * defaults to 1
         * */
        range?: number;
    }[];
};
type VolumeOpts<Manifest extends T.SDKManifest> = {
    /** The ID of the volume to mount. Must be one of the volume IDs defined in the manifest */
    volumeId: Manifest['volumes'][number];
    /** Whether or not the resource should be readonly for this subcontainer */
    readonly: boolean;
} & SharedOptions;
type DependencyOpts<Manifest extends T.SDKManifest> = {
    /** The ID of the dependency */
    dependencyId: Manifest['id'];
    /** The ID of the volume to mount. Must be one of the volume IDs defined in the manifest of the dependency */
    volumeId: Manifest['volumes'][number];
    /** Whether or not the resource should be readonly for this subcontainer */
    readonly: boolean;
} & Omit<SharedOptions, 'type'>;
/**
 * Immutable builder for declaring filesystem mounts into a subcontainer.
 *
 * Supports mounting volumes, static assets, dependency volumes, and shared volumes.
 * Each `mount*` method returns a new `Mounts` instance (immutable builder pattern).
 *
 * @typeParam Manifest - The service manifest type
 */
export declare class Mounts<Manifest extends T.SDKManifest> {
    readonly volumes: VolumeOpts<Manifest>[];
    readonly assets: SharedOptions[];
    readonly dependencies: DependencyOpts<T.SDKManifest>[];
    readonly sharedVolumes: SharedVolumeMountOptions[];
    private constructor();
    /**
     * Create an empty Mounts builder with no mounts configured.
     * @returns A new Mounts instance ready for chaining mount declarations
     */
    static of<Manifest extends T.SDKManifest>(): Mounts<Manifest>;
    /**
     * Add a volume mount from the service's own volumes.
     * @param options - Volume ID, mountpoint, readonly flag, and optional subpath
     * @returns A new Mounts instance with this volume added
     */
    mountVolume(options: VolumeOpts<Manifest>): Mounts<Manifest>;
    /**
     * Add a read-only mount of the service's packaged static assets.
     * @param options - Mountpoint and optional subpath within the assets directory
     * @returns A new Mounts instance with this asset mount added
     */
    mountAssets(options: SharedOptions): Mounts<Manifest>;
    /**
     * Add a mount from a dependency package's volume. The mount is always a
     * directory — StartOS does not bind a dependency's file. To reach a single
     * file, mount the directory holding it. The volume must exist when the
     * container starts; a missing dependency fails the start.
     *
     * @param options - Dependency ID, volume ID, mountpoint, readonly flag, and optional subpath
     * @returns A new Mounts instance with this dependency mount added
     */
    mountDependency<DependencyManifest extends T.SDKManifest>(options: DependencyOpts<DependencyManifest>): Mounts<Manifest>;
    /**
     * Declare an essential shared volume. Unavailability rejects subcontainer construction.
     * Prefer `SubContainer.tryMountSharedVolume` for optional functionality.
     */
    mountSharedVolume(this: Manifest extends {
        sharedVolumes: true;
    } ? Mounts<Manifest> : never, options: SharedVolumeMountOptions): Mounts<Manifest>;
    /**
     * Compile all declared mounts into the low-level mount array consumed by the subcontainer runtime.
     * @throws If any two mounts share the same mountpoint
     * @returns An array of `{ mountpoint, options }` objects
     */
    build(): MountArray;
}
export {};
