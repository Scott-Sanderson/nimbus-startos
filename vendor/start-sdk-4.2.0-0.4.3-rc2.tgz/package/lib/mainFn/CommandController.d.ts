import * as T from '@start9labs/start-core/types';
import { SubContainer } from '../util/SubContainer';
import { Drop } from '../util';
import { DaemonCommandType } from './Daemons';
/**
 * Low-level controller for a single running process inside a subcontainer (or as a JS function).
 *
 * Manages the child process lifecycle: spawning, waiting, and signal-based termination.
 * Used internally by {@link Daemon} to manage individual command executions.
 *
 * @typeParam Manifest - The service manifest type
 * @typeParam C - The subcontainer type, or `null` for JS-only commands
 */
export declare class CommandController<Manifest extends T.SDKManifest, C extends SubContainer<Manifest> | null> extends Drop {
    readonly runningAnswer: Promise<null>;
    private state;
    private readonly subcontainer;
    private process;
    readonly sigtermTimeout: number;
    private constructor();
    /**
     * Factory method to create a new CommandController.
     *
     * Returns a curried async function: `(effects, subcontainer, exec) => CommandController`.
     * If the exec spec has an `fn` property, runs the function; otherwise spawns a shell command
     * in the subcontainer.
     */
    static of<Manifest extends T.SDKManifest, C extends SubContainer<Manifest> | null>(): (effects: T.Effects, subcontainer: C, exec: DaemonCommandType<Manifest, C>) => Promise<CommandController<Manifest, C>>;
    /**
     * Wait for the command to finish. Optionally terminate after a timeout.
     * @param options.timeout - Milliseconds to wait before terminating. Defaults to no timeout.
     */
    wait({ timeout }?: {
        timeout?: number | undefined;
    }): Promise<void>;
    /**
     * Terminate the running command by sending a signal.
     *
     * Sends the specified signal (default: SIGTERM), then escalates to SIGKILL
     * after the timeout expires, and awaits the process's exit. Does not touch
     * the SubContainer — its lifecycle is owned by {@link Daemon} (`stop`/`term`).
     *
     * @param options.signal - The signal to send (default: SIGTERM)
     * @param options.timeout - Milliseconds before escalating to SIGKILL
     */
    term({ signal, timeout }?: {
        signal?: NodeJS.Signals | undefined;
        timeout?: number | undefined;
    }): Promise<void>;
    onDrop(): void;
}
