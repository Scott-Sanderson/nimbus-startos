import * as T from '@start9labs/start-core/types';
import { SubContainer } from '../util/SubContainer';
import { Daemon } from './Daemon';
import { DaemonCommandType } from './Daemons';
/**
 * This is a wrapper around CommandController that has a state of off, where the command shouldn't be running
 * and the others state of running, where it will keep a living running command
 * unlike Daemon, does not restart on success
 */
export declare class Oneshot<Manifest extends T.SDKManifest, C extends SubContainer<Manifest> | null = SubContainer<Manifest> | null> extends Daemon<Manifest, C> {
    static of<Manifest extends T.SDKManifest>(): <C extends SubContainer<Manifest> | null>(effects: T.Effects, subcontainer: C, exec: DaemonCommandType<Manifest, C>) => Oneshot<Manifest, C>;
}
