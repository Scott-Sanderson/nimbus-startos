import * as T from '@start9labs/start-core/types';
import { Drop } from '../util';
import { SubContainer } from '../util/SubContainer';
import { CommandController } from './CommandController';
import { DaemonCommandType } from './Daemons';
import { Oneshot } from './Oneshot';
/**
 * A managed long-running process wrapper around {@link CommandController}.
 *
 * When started, the daemon automatically restarts its underlying command on
 * failure with exponential backoff (up to 30 seconds). While the daemon is
 * running, it holds a use-token (`subcontainer.hold()`) on its SubContainer
 * so the container is not destroyed out from under it. There are two ways to
 * bring it down: {@link stop} releases the hold but leaves the SubContainer
 * intact so a later {@link start} can resume in it (a restartable pause);
 * {@link term} additionally destroys the SubContainer (genuine teardown).
 *
 * @typeParam Manifest - The service manifest type
 * @typeParam C - The subcontainer type, or `null` for JS-only daemons
 */
export declare class Daemon<Manifest extends T.SDKManifest, C extends SubContainer<Manifest> | null = SubContainer<Manifest> | null> extends Drop {
    readonly subcontainer: C;
    private startCommand;
    readonly oneshot: boolean;
    private commandController;
    protected exitedSuccess: boolean;
    private onExitFns;
    private loop;
    private releaseSubcontainerHold;
    private detached;
    private _lastExitError;
    private _failedExits;
    protected constructor(subcontainer: C, startCommand: () => Promise<CommandController<Manifest, C>>, oneshot?: boolean);
    /** Returns true if this daemon is a one-shot process (exits after success) */
    isOneshot(): this is Oneshot<Manifest>;
    /**
     * The error from the most recent abnormal exit, or `null` if none has been
     * recorded. An exit driven by {@link stop} or {@link term} is deliberate and
     * does not set this; the restart loop otherwise logs the error and retries,
     * retaining it here rather than reporting it to anyone.
     */
    get lastExitError(): Error | null;
    /**
     * How many times the process has exited abnormally over this daemon's
     * lifetime. Nothing resets it — neither a restart nor a
     * {@link stop}/{@link start} cycle — so a non-zero count means the process
     * has died at least once, not that it is dying now.
     */
    get failedExits(): number;
    /**
     * Factory method to create a new Daemon.
     *
     * Returns a curried function: `(effects, subcontainer, exec) => Daemon`.
     * Registers an `effects.onLeaveContext` hook that terminates the daemon
     * on parent-context teardown — suppressed once {@link detach} is called,
     * which a {@link Daemons} chain does for every daemon it builds so
     * `Daemons.term()` can drive dependency-ordered shutdown instead.
     */
    static of<Manifest extends T.SDKManifest>(): <C extends SubContainer<Manifest> | null>(effects: T.Effects, subcontainer: C, exec: DaemonCommandType<Manifest, C>) => Daemon<Manifest, C>;
    /**
     * Detach this daemon from the effects context it was created under, so a
     * context-leave (`onLeaveContext`) no longer terminates it. (The
     * subcontainer is already detached at construction — the daemon owns its
     * teardown — so this only governs the daemon's own self-term.) The owner
     * then controls teardown:
     *
     * - {@link Daemons} calls this on each daemon it builds, so the chain's
     *   `term()` drives dependency-ordered shutdown rather than each daemon
     *   self-terminating on context-leave.
     * - Called directly, it lets a daemon launched from a short-lived context
     *   (e.g. an action) outlive that context — the caller then owns the
     *   lifecycle and must call {@link term} explicitly.
     *
     * Idempotent.
     */
    detach(): void;
    /**
     * Start the daemon. If it is already running, this is a no-op.
     *
     * Takes a `hold()` on the daemon's SubContainer (if any) so the container
     * is kept alive while the daemon runs. The hold is released by {@link stop}
     * (a restartable pause) or {@link term} (teardown). The daemon automatically
     * restarts on failure with increasing backoff until `stop`/`term` is called.
     */
    start(): Promise<void>;
    private runLoop;
    /**
     * Stop the daemon's process and restart loop and release the SubContainer
     * hold taken at {@link start}, **without** destroying the SubContainer.
     * A subsequent {@link start} re-takes the hold and resumes in the same
     * container.
     *
     * This is the non-destroying counterpart to {@link term}: use it for a
     * temporary stop where the daemon is expected to start again — e.g. a
     * dependency going not-ready. Releasing the hold without requesting
     * destruction leaves the SubContainer alive (its leader keeps `proc/1`),
     * so the restart is cheaper than a destroy + recreate and — as long as
     * nothing else has requested destruction — the next `start()`'s `hold()`
     * succeeds rather than throwing `already destroyed`.
     *
     * Sends the configured signal (default SIGTERM) and waits for the process
     * to exit. Idempotent, and a no-op when the daemon is not running.
     *
     * @param termOptions Optional termination settings
     * @param termOptions.signal The signal to send (default `SIGTERM`)
     * @param termOptions.timeout Milliseconds to wait before escalating to `SIGKILL` (default = `Daemon`'s configured `sigtermTimeout`, ultimately `DEFAULT_SIGTERM_TIMEOUT`)
     */
    stop(termOptions?: {
        signal?: NodeJS.Signals | undefined;
        timeout?: number | undefined;
    }): Promise<void>;
    /**
     * Terminate the daemon: {@link stop} it (stop the process, abort the
     * restart loop, release the SubContainer hold taken at {@link start}) and
     * then request the SubContainer's destruction.
     *
     * `destroy()` is idempotent and defers to the last hold release, so other
     * daemons sharing the same SubContainer keep it alive until they also
     * term. Unlike {@link stop}, this is a one-way teardown — a `start()`
     * after `term()` throws `already destroyed`; use {@link stop} for a
     * restartable pause.
     *
     * Sends the configured signal (default SIGTERM) and waits for the
     * process to exit.
     *
     * @param termOptions Optional termination settings
     * @param termOptions.signal The signal to send (default `SIGTERM`)
     * @param termOptions.timeout Milliseconds to wait before escalating to `SIGKILL` (default = `Daemon`'s configured `sigtermTimeout`, ultimately `DEFAULT_SIGTERM_TIMEOUT`)
     */
    term(termOptions?: {
        signal?: NodeJS.Signals | undefined;
        timeout?: number | undefined;
    }): Promise<void>;
    /**
     * Register a callback to be invoked each time the daemon's process exits.
     * @param fn - Callback receiving `true` on clean exit, `false` on error
     */
    onExit(fn: (success: boolean) => void): void;
    onDrop(): void;
}
