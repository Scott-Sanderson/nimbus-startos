import { Ready } from './Daemons';
import { Daemon } from './Daemon';
import { Effects, SDKManifest } from '@start9labs/start-core/types';
export declare const EXIT_SUCCESS: "EXIT_SUCCESS";
export declare class HealthDaemon<Manifest extends SDKManifest> {
    readonly daemon: Daemon<Manifest> | null;
    readonly dependencies: HealthDaemon<Manifest>[];
    readonly id: string;
    readonly ready: Ready | typeof EXIT_SUCCESS;
    readonly effects: Effects;
    private _health;
    private healthWatchers;
    private running;
    private terminated;
    private transition;
    private started?;
    private resolveReady;
    private resolvedReady;
    private readyPromise;
    private session;
    constructor(daemon: Daemon<Manifest> | null, dependencies: HealthDaemon<Manifest>[], id: string, ready: Ready | typeof EXIT_SUCCESS, effects: Effects);
    term(termOptions?: {
        signal?: NodeJS.Signals | undefined;
        timeout?: number | undefined;
    }): Promise<void>;
    addWatcher(watcher: () => unknown): void;
    get health(): Readonly<({
        result: "success";
    } & {
        message?: string | null | undefined;
    }) | ({
        result: "disabled";
    } & {
        message?: string | null | undefined;
    }) | ({
        result: "starting";
    } & {
        message?: string | null | undefined;
        waiting?: boolean | undefined;
    }) | ({
        result: "loading";
    } & {
        message: string;
        waiting?: boolean | undefined;
    }) | ({
        result: "failure";
    } & {
        message: string;
    })>;
    private changeRunning;
    private applyRunning;
    private stopSession;
    private resetReady;
    private startSession;
    private runHealthCheckLoop;
    onReady(): Promise<void>;
    get isReady(): boolean;
    private setHealth;
    updateStatus(): Promise<void>;
}
