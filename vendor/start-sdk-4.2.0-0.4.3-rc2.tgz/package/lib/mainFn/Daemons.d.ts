import { HealthCheckResult } from '../health/checkFns';
import { Trigger } from '../trigger';
import * as T from '@start9labs/start-core/types';
import { SubContainer } from '../util/SubContainer';
import * as CP from 'node:child_process';
export { Daemon } from './Daemon';
export { CommandController } from './CommandController';
import { HealthDaemon } from './HealthDaemon';
import { Daemon } from './Daemon';
import { CommandController } from './CommandController';
/** Promisified version of `child_process.exec` */
export declare const cpExec: typeof CP.exec.__promisify__;
/** Promisified version of `child_process.execFile` */
export declare const cpExecFile: typeof CP.execFile.__promisify__;
/**
 * Configuration for a daemon's health-check readiness probe.
 *
 * Every daemon and standalone health check requires a `Ready` configuration
 * that tells StartOS how to determine whether the daemon is healthy.
 *
 * The `fn` is called on a recurring interval controlled by `trigger` (defaults
 * to 1 s before the first non-pending result, then 30 s). During the initial
 * `gracePeriod` window, `failure` results are softened to `starting` so the
 * UI doesn't flash red while a daemon is still booting.
 *
 * ### Health check result states
 *
 * | Result      | Meaning                                              | UI treatment     |
 * |-------------|------------------------------------------------------|------------------|
 * | `success`   | Healthy and fully operational                        | Green / ready    |
 * | `loading`   | Operational but still catching up (e.g. syncing)     | Progress / amber |
 * | `disabled`  | Intentionally inactive (excluded by configuration)   | Grey / skipped   |
 * | `starting`  | Not yet ready, still initializing                    | Spinner          |
 * | `failure`   | Unhealthy — something is wrong                       | Red / error      |
 *
 * `starting` and `loading` accept `waiting: true` to display a clock instead
 * of a spinner. Every status accepts a message displayed verbatim.
 */
export type Ready = {
    /**
     * Human-readable label shown in the StartOS health-check UI.
     * Set to `null` to hide this check from the UI entirely.
     */
    display: string | null;
    /**
     * The function called on each polling interval to determine the daemon's health.
     *
     * Return a {@link HealthCheckResult} with a `result` field (`success`, `loading`,
     * `failure`, etc.) and an optional `message` string shown in the UI.
     *
     * The SDK ships several built-in helpers on `sdk.healthCheck`:
     * - `checkPortListening` — checks whether a TCP port is listening or a UDP port is bound
     * - `checkWebUrl` — fetches a URL and succeeds on any HTTP response
     * - `runHealthScript` — runs a command in a subcontainer and succeeds on exit 0
     *
     * @example
     * ```ts
     * fn: () =>
     *   sdk.healthCheck.checkPortListening(effects, 80, {
     *     successMessage: 'Web server is ready',
     *     errorMessage: 'Web server is not listening',
     *   })
     * ```
     */
    fn: () => Promise<HealthCheckResult> | HealthCheckResult;
    /**
     * Duration in milliseconds during which `failure` results are reported
     * as `starting` instead, giving the daemon time to initialize without
     * showing errors in the UI.
     *
     * @default 10_000
     */
    gracePeriod?: number;
    /**
     * Controls the polling interval for this health check.
     *
     * Use one of the built-in triggers from `sdk.trigger`:
     * - `cooldownTrigger(ms)` — fixed interval between checks
     * - `onceTrigger` — one check at start, for a result fixed until `main`
     *   restarts; pair with `gracePeriod: 0`
     * - `statusTrigger(defaultMs, { success, loading, failure, ... })` —
     *   per-status polling intervals
     *
     * If omitted, polls every 1 s while `starting` or `failure` and every
     * 30 s otherwise (including `starting` with `waiting: true`), except that
     * `loading` or `waiting: true` before the first `success` backs off from
     * 1 s, doubling to 30 s.
     */
    trigger?: Trigger;
};
/**
 * Options for running a daemon as a shell command inside a subcontainer.
 * Non-init commands inherit each output stream without a callback from the runtime.
 */
export type ExecCommandOptions = {
    /** The command and arguments to execute (e.g. `['bitcoind', '-conf=/etc/bitcoin.conf']`) */
    command: T.CommandType;
    /**
     * How long (ms) to wait for the process to exit after sending SIGTERM
     * before force-killing it.
     *
     * @default 60_000
     */
    sigtermTimeout?: number;
    /** Run the command as PID 1 inside the container (init process) */
    runAsInit?: boolean;
    /** Environment variables to set for the process */
    env?: {
        [variable in string]?: string;
    } | undefined;
    /** Working directory for the process */
    cwd?: string | undefined;
    /** Run the process as this user inside the container */
    user?: string | undefined;
    /** Callback invoked with each chunk written to stdout */
    onStdout?: (chunk: Buffer | string | any) => void;
    /** Callback invoked with each chunk written to stderr */
    onStderr?: (chunk: Buffer | string | any) => void;
};
/**
 * Options for running a daemon via an async function that may optionally return
 * a command to execute in the subcontainer. The function receives an `AbortSignal`
 * for cooperative cancellation.
 */
export type ExecFnOptions<Manifest extends T.SDKManifest, C extends SubContainer<Manifest> | null> = {
    fn: (subcontainer: C, abort: AbortSignal) => Promise<C extends null ? null : ExecCommandOptions | null>;
    sigtermTimeout?: number;
};
/**
 * The execution specification for a daemon: either an {@link ExecFnOptions} (async function)
 * or an {@link ExecCommandOptions} (shell command, only valid when a subcontainer is provided).
 */
export type DaemonCommandType<Manifest extends T.SDKManifest, C extends SubContainer<Manifest> | null> = ExecFnOptions<Manifest, C> | (C extends null ? never : ExecCommandOptions);
type NewDaemonParams<Manifest extends T.SDKManifest, C extends SubContainer<Manifest> | null> = {
    /** What to run as the daemon: either an async fn or a commandline command to run in the subcontainer */
    exec: DaemonCommandType<Manifest, C>;
    /** The subcontainer in which the daemon runs */
    subcontainer: C;
    /**
     * Values this daemon/oneshot's closures use, folded into the entry's
     * `configHash` under `Daemons.dynamic`: when they change between
     * reconciliations, the daemon/oneshot is restarted. Closures
     * (`exec.fn`, `ready.fn`) are invisible to the hash, so anything they
     * capture that the reconciler should react to must be listed here.
     *
     * Only JSON-serializable values are useful here — functions, symbols,
     * cycles and `undefined` normalize to an `UNSERIALIZABLE:*` sentinel,
     * so a change only visible there triggers no restart; BigInts hash as
     * their decimal string.
     */
    uses?: unknown;
};
type OptionalParamSync<T> = T | (() => T | null);
type OptionalParamAsync<T> = () => Promise<T | null>;
type AddDaemonParams<Manifest extends T.SDKManifest, Ids extends string, Id extends string, C extends SubContainer<Manifest> | null> = (NewDaemonParams<Manifest, C> | {
    daemon: Daemon<Manifest>;
}) & {
    ready: Ready;
    /**
     * IDs of prior daemons/oneshots/health checks that must be ready before
     * this daemon starts. Enforces startup ordering in the daemon chain.
     */
    requires: Exclude<Ids, Id>[];
    /**
     * Values this daemon uses — see {@link NewDaemonParams.uses}. This is
     * the only way to make the reconciler react to a change inside a
     * pre-built `{ daemon }`, which is otherwise entirely opaque to the
     * hash.
     */
    uses?: unknown;
};
type AddOneshotParams<Manifest extends T.SDKManifest, Ids extends string, Id extends string, C extends SubContainer<Manifest> | null> = NewDaemonParams<Manifest, C> & {
    /**
     * IDs of prior daemons/oneshots/health checks that must be ready before
     * this oneshot runs.
     */
    requires: Exclude<Ids, Id>[];
};
type AddHealthCheckParams<Ids extends string, Id extends string> = {
    ready: Ready;
    /**
     * IDs of prior daemons/oneshots/health checks that must be ready before
     * this health check starts polling.
     */
    requires: Exclude<Ids, Id>[];
};
type ErrorDuplicateId<Id extends string> = `The id '${Id}' is already used`;
/** Recorder entry for a `Daemons` chain. Materialized into `HealthDaemon`s at build/reconcile time. */
type DaemonEntry<M extends T.SDKManifest> = {
    kind: 'daemon';
    id: string;
    subcontainer: SubContainer<M> | null;
    exec: DaemonCommandType<M, SubContainer<M> | null>;
    ready: Ready;
    requires: ReadonlyArray<string>;
    uses: unknown;
    /** If supplied via the `{ daemon: ... }` form, pre-built daemon. */
    prebuiltDaemon: Daemon<M> | null;
} | {
    kind: 'oneshot';
    id: string;
    subcontainer: SubContainer<M> | null;
    exec: DaemonCommandType<M, SubContainer<M> | null>;
    requires: ReadonlyArray<string>;
    uses: unknown;
} | {
    kind: 'health';
    id: string;
    ready: Ready;
    requires: ReadonlyArray<string>;
};
export declare const runCommand: <Manifest extends T.SDKManifest>() => (effects: T.Effects, subcontainer: SubContainer<Manifest, T.Effects>, exec: DaemonCommandType<Manifest, SubContainer<Manifest, T.Effects>>) => Promise<CommandController<Manifest, SubContainer<Manifest, T.Effects>>>;
/**
 * A class for defining and controlling the service daemons
 *
 * `Daemons` is a record-then-build container: each `.addDaemon(...)` /
 * `.addOneshot(...)` / `.addHealthCheck(...)` call appends an entry to an
 * internal list (no `HealthDaemon` or `SubContainer.createFs` work happens
 * yet). The chain is materialized when {@link build} is called (for static
 * topologies in {@link setupMain}) or progressively, per entry, by
 * {@link Daemons.dynamic} (for topologies that change at runtime).
 *
 * Backward-compatible with the prior eager builder: `Daemons.of(...).addDaemon(...).build()`
 * still produces a running chain. The only externally visible change is that
 * `HealthDaemon` instances exist after `build()` rather than after each
 * `.addDaemon()`.
 *
 * @example
 * ```ts
 * sdk.Daemons.of({ effects })
 *   .addDaemon('webui', {
 *     subcontainer: sdk.SubContainer.of(effects, { imageId: 'main' }, mounts, 'webui'),
 *     exec: { command: ['hello-world'] },
 *     ready: {
 *       display: 'Web Interface',
 *       // The function to run to determine the health status of the daemon
 *       fn: () =>
 *         checkPortListening(effects, 80, {
 *           successMessage: 'The web interface is ready',
 *           errorMessage: 'The web interface is not ready',
 *         }),
 *     },
 *     requires: [],
 *   })
 * ```
 */
export declare class Daemons<Manifest extends T.SDKManifest, Ids extends string> implements T.DaemonBuildable {
    readonly effects: T.Effects;
    readonly ids: Ids[];
    readonly entries: ReadonlyArray<DaemonEntry<Manifest>>;
    private builtHealthDaemons;
    private termPromise;
    private detached;
    private constructor();
    /**
     * Returns an empty new Daemons class.
     *
     * Call .addDaemon() on the returned class to add a daemon. Daemons run in
     * the order they are defined; later daemons may depend on prior daemons.
     */
    static of<Manifest extends T.SDKManifest>(options: {
        effects: T.Effects;
    }): Daemons<Manifest, never>;
    /**
     * Reconcile a reactive daemon set within `setupMain` on each `effects.constRetry`.
     *
     * The supplied builder returns a {@link Daemons} (in record-mode, not yet
     * built); the SDK diffs its entries against the running daemons by
     * `(id, configHash)`. Per id: absent → present **start**, present →
     * absent **stop**, unchanged configuration **leave alone**, changed configuration **restart**.
     * Shared-container membership is part of the configuration. A stopped or
     * restarted container refreshes all its processes and their dependents.
     * Re-runs are coalesced.
     *
     * Invalidations from `getSharedVolumes(...).const()` refresh containers with
     * declared or attempted shared-volume mounts even when metadata and hashes
     * remain equal. The callback covers the granted catalog, so its shared-volume
     * consumers refresh together; unrelated containers stay running. Nested effects
     * retain this reconciliation scope rather than restarting the whole service.
     *
     * The diff key (`configHash`) covers the subcontainer descriptor
     * (`imageId`, `sharedRun`, `name`, structural `mounts.build()`), the
     * whole `exec` options object, `requires` (sorted), the structural
     * parts of `ready` (`display`, `gracePeriod`), and the entry's
     * `uses`. Function values inside them (`exec.fn`, `exec.onStdout`,
     * `ready.fn`, `ready.trigger`) hash as constant sentinels — their
     * contents are intentionally invisible — as is any pre-built `Daemon`
     * instance: declare a captured value in `uses` if you want the
     * reconciler to react to it changing.
     *
     * **Use lazy SubContainers** ({@link SubContainer.of}) for daemons under
     * `Daemons.dynamic`, creating fresh handles inside `fn` on each evaluation.
     * Stopped handles are destroyed and cannot be reused. Eager handles created
     * inside `fn` materialize before diffing; the reconciler rejects them.
     *
     * Return the result from `setupMain` — it is a {@link T.DaemonBuildable},
     * exactly like a static `Daemons.of(...)` chain:
     *
     * ```typescript
     * export const main = sdk.setupMain(async ({ effects }) => {
     *   return sdk.Daemons.dynamic(effects, async ({ effects }) => {
     *     const sites = await storeJson.read((s) => s.sites).const(effects)
     *     return sdk.Daemons.of(effects).addDaemon(...)
     *   })
     * })
     * ```
     *
     * @param effects The effects context, from `setupMain`
     * @param fn Async builder invoked on startup and on every `constRetry`. Must return a `Daemons` in record-mode (not pre-`build()`-ed)
     * @returns A {@link DaemonsReconciler} — a `T.DaemonBuildable` to return from `setupMain`
     */
    static dynamic<Manifest extends T.SDKManifest>(effects: T.Effects, fn: DaemonsBuilder<Manifest>): DaemonsReconciler<Manifest>;
    private appendEntry;
    /**
     * Register a long-running daemon process.
     *
     * The daemon starts in its subcontainer and is monitored by its `ready`
     * health check. Other daemons and health checks can depend on it via
     * `requires`. Pass a static options object, a sync/async factory that
     * returns options (or `null` to conditionally skip the daemon), or an
     * object with a pre-built `daemon` instance.
     *
     * @param id Unique string identifier for this daemon
     * @param options Daemon configuration, or a factory returning it (return `null` to skip)
     */
    addDaemon<Id extends string, C extends SubContainer<Manifest> | null>(id: "" extends Id ? never : ErrorDuplicateId<Id> extends Id ? never : Id extends Ids ? ErrorDuplicateId<Id> : Id, options: OptionalParamSync<AddDaemonParams<Manifest, Ids, Id, C>>): Daemons<Manifest, Ids | Id>;
    addDaemon<Id extends string, C extends SubContainer<Manifest> | null>(id: "" extends Id ? never : ErrorDuplicateId<Id> extends Id ? never : Id extends Ids ? ErrorDuplicateId<Id> : Id, options: OptionalParamAsync<AddDaemonParams<Manifest, Ids, Id, C>>): Promise<Daemons<Manifest, Ids | Id>>;
    /**
     * Register a one-shot command that runs to completion before dependents
     * start. Common uses: `chown` for file ownership, database migrations,
     * config generation, wallet unlocking. The oneshot is considered "ready"
     * as soon as the command exits successfully (exit code 0).
     *
     * @param id Unique string identifier for this oneshot
     * @param options Oneshot configuration, or a factory returning it (return `null` to skip)
     */
    addOneshot<Id extends string, C extends SubContainer<Manifest> | null>(id: "" extends Id ? never : ErrorDuplicateId<Id> extends Id ? never : Id extends Ids ? ErrorDuplicateId<Id> : Id, options: OptionalParamSync<AddOneshotParams<Manifest, Ids, Id, C>>): Daemons<Manifest, Ids | Id>;
    addOneshot<Id extends string, C extends SubContainer<Manifest> | null>(id: "" extends Id ? never : ErrorDuplicateId<Id> extends Id ? never : Id extends Ids ? ErrorDuplicateId<Id> : Id, options: OptionalParamAsync<AddOneshotParams<Manifest, Ids, Id, C>>): Promise<Daemons<Manifest, Ids | Id>>;
    /**
     * Register a standalone health check with no associated process.
     *
     * Use this for ongoing conditions that don't map to a single daemon,
     * such as blockchain sync progress or network reachability. Dependent
     * services can reference standalone health check IDs in their
     * dependency config.
     *
     * @param id Unique string identifier for this health check
     * @param options Health check configuration, or a factory returning it (return `null` to skip)
     */
    addHealthCheck<Id extends string>(id: "" extends Id ? never : ErrorDuplicateId<Id> extends Id ? never : Id extends Ids ? ErrorDuplicateId<Id> : Id, options: OptionalParamSync<AddHealthCheckParams<Ids, Id>>): Daemons<Manifest, Ids | Id>;
    addHealthCheck<Id extends string>(id: "" extends Id ? never : ErrorDuplicateId<Id> extends Id ? never : Id extends Ids ? ErrorDuplicateId<Id> : Id, options: OptionalParamAsync<AddHealthCheckParams<Ids, Id>>): Promise<Daemons<Manifest, Ids | Id>>;
    /**
     * Build the daemon chain: walks the recorded entries top-down,
     * constructs `HealthDaemon`s with correct dependency wiring, registers
     * an `onLeaveContext` cleanup, and kicks off status updates.
     *
     * Idempotent — repeat calls return the same `Daemons` without rebuilding.
     *
     * **No-leak invariant**: an `onLeaveContext` shutdown handler is armed
     * *before* any daemon is constructed, and every partial construction is
     * tracked in `builtHealthDaemons` so {@link term} can clean it up.
     * Anything that throws during construction or `updateStatus` triggers
     * an immediate `term()` (which is also idempotent) before the failure
     * propagates.
     */
    build(): Promise<this>;
    /** Health daemons after {@link build}, or empty before it runs. */
    get healthDaemons(): ReadonlyArray<HealthDaemon<Manifest>>;
    /**
     * Start all registered daemons and wait until every one passes its
     * ready check, then tear everything down. Used for bootstrapping via a
     * temporary daemon chain — e.g. starting a service to call its API
     * (create admin users, register apps), then shutting it down before
     * the real daemon chain starts.
     *
     * @param timeout Maximum time (ms) to wait for all daemons to become ready, or `null` for no limit
     * @throws If the timeout is reached before all daemons are ready
     */
    runUntilSuccess(timeout: number | null): Promise<null>;
    /**
     * Human-readable account of every daemon that has not reached ready, each
     * with its current health result and message, plus the count and last cause
     * of any abnormal exits.
     *
     * The exit count sits alongside the current health rather than replacing it
     * because the two disagree in the case that matters most: a `ready` check
     * that returns `loading` on a failed probe overwrites the crash back to
     * `loading` on its next poll, so health alone reads as "still starting" for
     * a process that is dying every time.
     *
     * {@link RUN_UNTIL_SUCCESS_ID} is excluded — it depends on every other
     * daemon, so it is never ready when anything else isn't.
     */
    private describeNotReady;
    /**
     * Detach this `Daemons` from the effects context it was built under, so a
     * context-leave (`onLeaveContext`) no longer terminates the chain. Each
     * managed daemon already owns its subcontainer (detached from the context
     * at construction) and has its self-term suppressed by {@link build}, so
     * this only stops the chain's own `term()` from firing on context-leave —
     * and the whole chain then outlives the context that created it.
     *
     * Use when a short-lived context — e.g. an action — needs to launch
     * daemons that outlive it. After detaching, the caller owns the lifecycle:
     * nothing is torn down until {@link term} is called explicitly. Idempotent,
     * and safe to call before or after {@link build}.
     */
    detach(): void;
    /**
     * Gracefully terminate all daemons in reverse dependency order and
     * destroy every unique SubContainer that was registered with this
     * `Daemons`. Idempotent.
     */
    term(): Promise<void>;
    private _term;
}
/** The user-supplied builder consumed by {@link Daemons.dynamic}. */
export type DaemonsBuilder<M extends T.SDKManifest> = (opts: {
    effects: T.Effects;
}) => Promise<Daemons<M, any>> | Daemons<M, any>;
/**
 * Stable JSON hash over the structural args of a recorded entry.
 *
 * Two entries with the same id and the same `configHash` are considered
 * structurally equal. The reconciler leaves them running while shared-container
 * membership and shared-volume dependencies remain unchanged. Any hash
 * difference triggers a restart.
 *
 * Hashed fields: kind, id, sorted requires, subcontainer descriptor
 * (`imageId`, `sharedRun`, `name`, `mounts.build()`), the whole `exec`
 * options object, ready's structural parts (`display`, `gracePeriod`),
 * and `uses`.
 *
 * Function values (`exec.fn`, `exec.onStdout`, `ready.fn`,
 * `ready.trigger`) hash as constant `UNSERIALIZABLE:FUNCTION`
 * sentinels — two different closures hash alike, so their contents
 * never trigger a restart — and a pre-built `daemon` instance is not
 * hashed at all. `uses` is the escape hatch for values only visible
 * inside those closures.
 *
 * `uses` is canonicalized like every other hashed field, and never
 * throws: functions, symbols, cycles and `undefined` normalize to an
 * `UNSERIALIZABLE:*` sentinel (so changes only visible there trigger
 * no restart), and BigInts hash as their decimal string.
 *
 * @param entry A recorded {@link Daemons} entry (`Daemons.entries[i]`)
 * @returns A canonical JSON string suitable for equality comparison
 */
export declare function configHash<M extends T.SDKManifest>(entry: DaemonEntry<M>): string;
/**
 * Reconciles a {@link Daemons} (in record-mode) against a running set on
 * every `effects.constRetry` trigger.
 *
 * Construction is internal — get one by calling {@link Daemons.dynamic}.
 * Implements {@link T.DaemonBuildable}: `build()` performs the first
 * reconcile and wires up the re-run trigger; `term()` shuts everything
 * down in dependent-first order.
 */
export declare class DaemonsReconciler<M extends T.SDKManifest> implements T.DaemonBuildable {
    private readonly rootEffects;
    private readonly fn;
    private running;
    private inFlight;
    private pendingRerun;
    private sharedVolumesRevision;
    private isTerminating;
    private termPromise;
    private detached;
    constructor(rootEffects: T.Effects, fn: DaemonsBuilder<M>);
    build(): Promise<{
        term(): Promise<void>;
        detach(): void;
    }>;
    /**
     * Detach the reconciler from `rootEffects`, so a context-leave no longer
     * terminates the daemons or destroys their containers. Each daemon is
     * already detached from the context as it starts (in `startEntry`), so this
     * only stops the reconciler's own `term()` from firing on context-leave.
     * After detaching, the caller owns the lifecycle and must call `term()`
     * explicitly. Idempotent.
     */
    detach(): void;
    /** Trigger an out-of-band reconcile. Internal — exposed for testing. */
    scheduleRerun(): void;
    private builderEffects;
    private runReconcile;
    private reconcile;
    private stopEntries;
    private startEntry;
    private term;
}
