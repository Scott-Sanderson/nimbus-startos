import { Backups } from './Backups';
import * as T from '@start9labs/start-core/types';
import { InitScript } from '@start9labs/start-core/inits';
/**
 * Parameters for `setupBackups`. Either:
 * - An array of volume IDs to back up entirely, or
 * - An async factory function that returns a fully configured {@link Backups} instance
 */
export type SetupBackupsParams<M extends T.SDKManifest> = M['volumes'][number][] | ((_: {
    effects: T.Effects;
}) => Promise<Backups<M>>);
type SetupBackupsRes = {
    createBackup: T.ExpectedExports.createBackup;
    restoreInit: InitScript;
};
/**
 * Set up backup and restore exports for the service.
 *
 * Returns `{ createBackup, restoreInit }` which should be exported and wired into
 * the service's init and backup entry points.
 *
 * @param options - Either an array of volume IDs or an async factory returning a Backups instance
 * @returns An object with `createBackup` (the backup export) and `restoreInit` (an InitScript for restore)
 */
export declare function setupBackups<M extends T.SDKManifest>(options: SetupBackupsParams<M>): SetupBackupsRes;
export {};
