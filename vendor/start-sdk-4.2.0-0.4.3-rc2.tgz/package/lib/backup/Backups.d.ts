import * as T from '@start9labs/start-core/types';
import { Affine } from '../util';
import { InitKind, InitScript } from '@start9labs/start-core/inits';
import { FullProgressTracker, PhaseHandle } from '@start9labs/start-core/util/FullProgressTracker';
/** A password value, or a function that returns one. Functions are resolved when a backup or restore hook runs. */
export type LazyPassword = string | (() => string | Promise<string>) | null;
/** Configuration for PostgreSQL dump-based backup */
export type PgDumpConfig<M extends T.SDKManifest> = {
    /** Image ID of the PostgreSQL container (e.g. 'postgres') */
    imageId: keyof M['images'] & T.ImageId;
    /** Volume ID containing the PostgreSQL data directory */
    dbVolume: M['volumes'][number];
    /** Volume mountpoint (e.g. '/var/lib/postgresql') */
    mountpoint: string;
    /** Subpath from mountpoint to PGDATA (e.g. '/data', '/18/docker') */
    pgdataPath: string;
    /** PostgreSQL database name to dump */
    database: string;
    /** PostgreSQL user */
    user: string;
    /** PostgreSQL password (for restore). Can be a string, a function that returns one (resolved lazily after volumes are restored), or null for trust auth. */
    password: LazyPassword;
    /** Additional initdb arguments (e.g. ['--data-checksums']) */
    initdbArgs?: string[];
    /** Additional options passed to `pg_ctl start -o` (e.g. '-c shared_preload_libraries=vectorchord'). Appended after `-c listen_addresses=`. */
    pgOptions?: string;
    /** Milliseconds to wait for PostgreSQL to accept connections before failing (default 60000). Also passed to `pg_ctl` as `-t`, bounding its own wait for startup and for the shutdown checkpoint. Raise for large clusters that need longer to start, run crash recovery, or shut down. */
    readyTimeout?: number;
};
/** Options for rebuilding a MySQL data volume from a logical dump. */
export type MysqlDumpConfig<M extends T.SDKManifest> = {
    /** Manifest image containing the MySQL server and client tools. */
    imageId: keyof M['images'] & T.ImageId;
    /** Volume rebuilt from the logical dump during restore. */
    dbVolume: M['volumes'][number];
    /** Mount point for the database volume inside the image. */
    datadir: string;
    /** Database included in the logical dump. */
    database: string;
    /** Account used to create the dump and recreated on restore. */
    user: string;
    /** Dump-account password, resolved after volumes return on restore. Non-null values also configure root. */
    password: LazyPassword;
    /** Backup readiness probe; defaults to `mysqladmin ping` as the dump account. */
    readyCommand?: string[];
    /** Appended after `--bind-address=127.0.0.1`. */
    mysqldOptions?: string[];
    /** Readiness timeout in milliseconds; defaults to 30,000. */
    readyTimeout?: number;
    engine?: 'mysql';
};
/** Options for rebuilding a MariaDB data volume from a logical dump. */
export type MariadbDumpConfig<M extends T.SDKManifest> = {
    /** Manifest image containing the MariaDB server and client tools. */
    imageId: keyof M['images'] & T.ImageId;
    /** Volume rebuilt from the logical dump during restore. */
    dbVolume: M['volumes'][number];
    /** Mount point for the database volume inside the image. */
    datadir: string;
    /** Database included in the logical dump. */
    database: string;
    /** Account used to create the dump and recreated on restore. */
    user: string;
    /** Dump-account password, resolved after volumes return on restore. Non-null values also configure root. */
    password: LazyPassword;
    /** Backup readiness probe; defaults to `mariadb-admin ping` as the dump account. */
    readyCommand?: string[];
    /** Appended after `--bind-address=127.0.0.1`. */
    mariadbdOptions?: string[];
    /** Readiness timeout in milliseconds; defaults to 30,000. */
    readyTimeout?: number;
    mysqldOptions?: never;
};
/**
 * Bind-mount the host backup directory (`/media/startos/backup`) into a
 * SubContainer's rootfs.
 *
 * Native 0.4 packages mount at the SDK's `/backup-target`; legacy
 * SystemForEmbassy packages pass the manifest-declared mountpoint so the
 * docker backup/restore procedure finds its `backup`-type volume where it
 * expects. Both paths share this single rbind so legacy backups go through
 * the same mechanism as native ones.
 */
export declare function mountBackupTarget(rootfs: string, containerPath?: string): Promise<void>;
/** Default rsync options used for backup and restore operations */
export declare const DEFAULT_OPTIONS: T.SyncOptions;
/**
 * Default progress weight of each rsync sync phase. rsync dominates a backup's
 * runtime, so it dominates the progress bar relative to the pre/post hooks.
 */
export declare const DEFAULT_SYNC_WEIGHT = 80;
/** Default progress weight of a pre/post backup or restore hook phase. */
export declare const DEFAULT_HOOK_WEIGHT = 10;
/** A single source-to-destination sync pair for backup and restore */
export type BackupSync<Volumes extends string> = {
    dataPath: `/media/startos/volumes/${Volumes}/${string}`;
    backupPath: `/media/startos/backup/${string}`;
    options?: Partial<T.SyncOptions>;
    backupOptions?: Partial<T.SyncOptions>;
    restoreOptions?: Partial<T.SyncOptions>;
    /** Progress weight of this sync's phase (default {@link DEFAULT_SYNC_WEIGHT}). */
    weight?: number;
};
/** Effects type narrowed for backup/restore contexts, preventing reuse outside that scope */
export type BackupEffects = T.Effects & Affine<'Backups'>;
/** A pre/post backup or restore hook, given a handle to its own progress phase. */
export type BackupHook = (effects: BackupEffects, progress: PhaseHandle) => Promise<void>;
/**
 * Configures backup and restore operations using rsync.
 *
 * Supports syncing entire volumes or custom path pairs, with optional pre/post hooks
 * for both backup and restore phases. Implements {@link InitScript} so it can be used
 * as a restore-init step in `setupInit`.
 *
 * @typeParam M - The service manifest type
 */
export declare class Backups<M extends T.SDKManifest> implements InitScript {
    private options;
    private restoreOptions;
    private backupOptions;
    private backupSet;
    private constructor();
    private preBackup?;
    private postBackup?;
    private preRestore?;
    private postRestore?;
    private preBackupWeight;
    private postBackupWeight;
    private preRestoreWeight;
    private postRestoreWeight;
    /**
     * Create a Backups configuration that backs up entire volumes by name.
     * Each volume is synced to a corresponding directory under `/media/startos/backup/volumes/`.
     * @param volumeNames - One or more volume IDs from the manifest
     */
    static ofVolumes<M extends T.SDKManifest = never>(...volumeNames: Array<M['volumes'][number]>): Backups<M>;
    /**
     * Create a Backups configuration from explicit source/destination sync pairs.
     * @param syncs - Array of `{ dataPath, backupPath }` objects with optional per-sync options
     */
    static ofSyncs<M extends T.SDKManifest = never>(...syncs: BackupSync<M['volumes'][number]>[]): Backups<M>;
    /**
     * Create an empty Backups configuration with custom default rsync options.
     * Chain `.addVolume()` or `.addSync()` to add sync targets.
     * @param options - Partial rsync options to override defaults (e.g. `{ exclude: ['cache'] }`)
     */
    static withOptions<M extends T.SDKManifest = never>(options?: Partial<T.SyncOptions>): Backups<M>;
    /**
     * Configure PostgreSQL dump-based backup for a volume.
     *
     * Instead of rsyncing the raw PostgreSQL data directory (which is slow and error-prone),
     * this uses `pg_dump` to create a logical dump before backup and `pg_restore` to rebuild
     * the database after restore.
     *
     * The dump is staged in the subcontainer's `/tmp` and copied to the backup
     * target, so it needs transient room for one copy of the dump.
     *
     * @returns A configured Backups instance with pre/post hooks. Chain `.addVolume()` or
     * `.addSync()` to include additional volumes/paths in the backup.
     */
    static withPgDump<M extends T.SDKManifest = never>(config: PgDumpConfig<M>): Backups<M>;
    /**
     * Backs up a MySQL database as a logical dump and rebuilds it on restore.
     *
     * Chain `.addVolume()` or `.addSync()` for additional backup content.
     */
    static withMysqlDump<M extends T.SDKManifest = never>(config: MysqlDumpConfig<M>): Backups<M>;
    /**
     * Backs up a MariaDB database as a compressed logical dump and rebuilds it on restore.
     *
     * Chain `.addVolume()` or `.addSync()` for additional backup content.
     */
    static withMariadbDump<M extends T.SDKManifest = never>(config: MariadbDumpConfig<M>): Backups<M>;
    /**
     * Override the default rsync options for both backup and restore.
     * @param options - Partial rsync options to merge with current defaults
     */
    setOptions(options?: Partial<T.SyncOptions>): this;
    /**
     * Override rsync options used only during backup (not restore).
     * @param options - Partial rsync options for the backup phase
     */
    setBackupOptions(options?: Partial<T.SyncOptions>): this;
    /**
     * Override rsync options used only during restore (not backup).
     * @param options - Partial rsync options for the restore phase
     */
    setRestoreOptions(options?: Partial<T.SyncOptions>): this;
    /**
     * Register a hook to run before backup rsync begins (e.g. dump a database).
     * @param fn - Async function receiving backup-scoped effects and a progress tracker for this hook
     */
    setPreBackup(fn: BackupHook, weight?: number): this;
    /**
     * Register a hook to run after backup rsync completes.
     * @param fn - Async function receiving backup-scoped effects and a progress tracker for this hook
     */
    setPostBackup(fn: BackupHook, weight?: number): this;
    /**
     * Register a hook to run before restore rsync begins.
     * @param fn - Async function receiving backup-scoped effects and a progress tracker for this hook
     */
    setPreRestore(fn: BackupHook, weight?: number): this;
    /**
     * Register a hook to run after restore rsync completes.
     * @param fn - Async function receiving backup-scoped effects and a progress tracker for this hook
     */
    setPostRestore(fn: BackupHook, weight?: number): this;
    /**
     * Add a volume to the backup set by its ID.
     * @param volume - The volume ID from the manifest
     * @param options - Optional per-volume rsync overrides
     */
    addVolume(volume: M['volumes'][number], options?: Partial<{
        options: T.SyncOptions;
        backupOptions: T.SyncOptions;
        restoreOptions: T.SyncOptions;
        weight: number;
    }>): this;
    /**
     * Add a custom sync pair to the backup set.
     * @param sync - A `{ dataPath, backupPath }` object with optional per-sync rsync options
     */
    addSync(sync: BackupSync<M['volumes'][0]>): this;
    /**
     * Execute the backup: runs pre-hook, rsyncs all configured paths, saves the data version, then runs post-hook.
     * @param effects - The effects context
     */
    createBackup(effects: T.Effects): Promise<void>;
    init(effects: T.Effects, kind: InitKind, progress?: FullProgressTracker): Promise<void>;
    /**
     * Execute the restore: runs pre-hook, rsyncs all configured paths from backup to data, restores the data version, then runs post-hook.
     * Restore runs as part of init, so progress reports through the init tracker.
     * @param effects - The effects context
     * @param progress - Tracker from the init harness (falls back to a no-op tracker)
     */
    restoreBackup(effects: T.Effects, progress?: FullProgressTracker): Promise<void>;
}
