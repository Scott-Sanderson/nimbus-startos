/** Resolves after `ms`, however long; never resolves for `Infinity`. */
export declare function delay(ms: number): Promise<void>;
