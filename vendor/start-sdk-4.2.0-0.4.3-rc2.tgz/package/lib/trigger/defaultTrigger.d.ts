import { Trigger } from '.';
/**
 * The trigger used when no explicit `trigger` is set on a health check.
 *
 * Polls every 1 s while `starting` or `failure`, and every 30 s while
 * `success`, `loading`, `disabled`, or `starting` with `waiting: true`,
 * except that `loading` or `waiting: true` before the first `success` backs
 * off from 1 s, doubling to 30 s.
 */
export declare const defaultTrigger: Trigger;
