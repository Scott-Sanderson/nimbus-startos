import { Effects } from '@start9labs/start-core/types';
import { HealthCheckResult } from './HealthCheckResult';
import 'isomorphic-fetch';
/**
 * Check whether a URL is reachable by performing an HTTP fetch.
 *
 * Succeeds on any HTTP response (regardless of status code). Fails if the
 * request errors out or exceeds the timeout.
 *
 * @param effects - The effects context
 * @param url - The URL to fetch
 * @param options.timeout - Maximum time (ms) to wait for a response (defaults to 1000)
 * @param options.successMessage - Message shown in the UI on success
 * @param options.errorMessage - Message shown in the UI on failure
 */
export declare const checkWebUrl: (effects: Effects, url: string, { timeout, successMessage, errorMessage, }?: {
    timeout?: number | undefined;
    successMessage?: string | undefined;
    errorMessage?: string | undefined;
}) => Promise<HealthCheckResult>;
