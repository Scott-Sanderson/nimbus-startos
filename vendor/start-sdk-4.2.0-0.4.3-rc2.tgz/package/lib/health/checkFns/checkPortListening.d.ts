import { Effects } from '@start9labs/start-core/types';
import { HealthCheckResult } from './HealthCheckResult';
export declare function containsAddress(x: string, port: number, address?: bigint, state?: number): boolean;
/**
 * Check whether a TCP port has a listening socket, or a UDP port is bound.
 *
 * Reads `/proc/net/tcp{,6}` and `/proc/net/udp{,6}`. A TCP socket counts only in
 * the `LISTEN` state, because connections that outlive their process keep the
 * port in `/proc/net/tcp` in `TIME_WAIT` for up to a minute after nothing is
 * listening on it. This is a lightweight, non-intrusive check — it does not open
 * a connection or send any data.
 *
 * @param effects - The effects context
 * @param port - Port number to check
 * @param options.successMessage - Message shown in the UI when the port is listening
 * @param options.errorMessage - Message shown in the UI when the port is not listening
 * @param options.timeoutMessage - Message shown if the check exceeds the timeout (defaults to `"Timeout trying to check port {port}"`)
 * @param options.timeout - Maximum time (ms) to wait before reporting failure (defaults to 1000)
 */
export declare function checkPortListening(effects: Effects, port: number, options: {
    errorMessage: string;
    successMessage: string;
    timeoutMessage?: string;
    timeout?: number;
}): Promise<HealthCheckResult>;
