import { HealthCheckResult } from './checkFns/HealthCheckResult';
export declare function withGracePeriod(health: HealthCheckResult, started: number | undefined, gracePeriod?: number): HealthCheckResult;
export declare function isInGracePeriod(started: number, gracePeriod?: number): boolean;
