import { Effects, HealthCheckId } from '@start9labs/start-core/types';
import { HealthCheckResult } from './checkFns/HealthCheckResult';
import { Trigger } from '../trigger';
import { Drop } from '@start9labs/start-core/util/Drop';
/** Parameters for creating a health check */
export type HealthCheckParams = {
    id: HealthCheckId;
    name: string;
    trigger?: Trigger;
    gracePeriod?: number;
    fn(): Promise<HealthCheckResult> | HealthCheckResult;
};
/**
 * A periodic health check that reports daemon readiness to the StartOS UI.
 *
 * Polls at an interval controlled by a {@link Trigger}, reporting results as
 * "starting" (during the grace period), "success", or "failure". Automatically
 * pauses when the daemon is stopped and resumes when restarted.
 */
export declare class HealthCheck extends Drop {
    private readonly o;
    private trigger;
    private started;
    private setStarted;
    private exited;
    private exit;
    private currentValue;
    private promise;
    private constructor();
    /**
     * Create a new HealthCheck instance and begin its polling loop.
     * @param effects - The effects context for reporting health status
     * @param options - Health check configuration (ID, name, check function, trigger, grace period)
     * @returns A new HealthCheck instance
     */
    static of(effects: Effects, options: HealthCheckParams): HealthCheck;
    /** Signal that the daemon is running, enabling health check polling */
    start(): void;
    /** Signal that the daemon has stopped, pausing health check polling */
    stop(): void;
    onDrop(): void;
}
