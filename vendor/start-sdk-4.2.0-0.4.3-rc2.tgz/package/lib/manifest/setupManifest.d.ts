import * as T from '@start9labs/start-core/types';
import { ImageId, VolumeId } from '@start9labs/start-core/types';
import { SDKManifest, SDKImageInputSpec } from '@start9labs/start-core/types/ManifestTypes';
import { Dependencies } from '../dependencies';
import { VersionGraph } from '../version/VersionGraph';
/**
 * Retypes every key the SDK does not define, so declaring one is a compile
 * error at that key rather than a field that silently does nothing. The
 * replacement is a string literal rather than `never` purely so the error names
 * what went wrong.
 *
 * TypeScript applies its excess-property check only when a fresh object literal
 * meets a non-generic target, and `Manifest` is inferred from the argument — so
 * without this an unknown field joins the inferred type, typechecks, and is
 * then dropped on the way to the built manifest.
 */
type NoExtraKeys<Manifest> = {
    [K in keyof Manifest]: K extends keyof SDKManifest ? Manifest[K] : 'Unknown manifest field — not declared in SDKManifest';
};
/**
 * @description Use this function to define critical information about your package
 *
 * @param manifest Static properties of the package
 */
export declare function setupManifest<Id extends string, VolumesTypes extends VolumeId, const Manifest extends {
    id: Id;
    volumes: VolumesTypes[];
} & SDKManifest>(manifest: Manifest & SDKManifest & NoExtraKeys<Manifest>): Manifest;
/**
 * Build the final publishable manifest by combining the SDK manifest definition
 * with version graph metadata, OS version, SDK version, and computed fields
 * (migration ranges, hardware requirements, etc.).
 *
 * @param versions - The service's VersionGraph, used to extract the current version, release notes, and migration ranges
 * @param manifest - The SDK manifest definition (from `setupManifest`)
 * @returns A fully resolved Manifest ready for packaging
 */
export declare function buildManifest<Id extends string, Version extends string, DependencyIds extends string, VolumesTypes extends VolumeId, ImagesTypes extends ImageId, Manifest extends {
    id: Id;
    images: Record<ImagesTypes, SDKImageInputSpec>;
    volumes: VolumesTypes[];
}>(versions: VersionGraph<Version>, manifest: SDKManifest & Manifest, dependencies: Dependencies<DependencyIds>): Manifest & T.Manifest;
export {};
